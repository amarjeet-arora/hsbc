package com.products.exceptions;

/*
 * Custom Exception Item does not exists extends Exception
 */

public class ItemDoesNotExist extends Exception{

	public ItemDoesNotExist() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemDoesNotExist(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
