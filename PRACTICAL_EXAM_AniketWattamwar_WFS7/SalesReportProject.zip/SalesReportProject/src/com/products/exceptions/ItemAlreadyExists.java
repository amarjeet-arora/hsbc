package com.products.exceptions;


/*
 * Custom Exception Item Already Exists extends Exception
 */

public class ItemAlreadyExists extends Exception{

	public ItemAlreadyExists() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemAlreadyExists(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
