package com.products.controller;

/*
 * Controller interface with methods called from the View
 */

public interface Controller {
	
	//Method Signatures
	public void addItem(String type);
	public void retrieveReport();
	
	
}
