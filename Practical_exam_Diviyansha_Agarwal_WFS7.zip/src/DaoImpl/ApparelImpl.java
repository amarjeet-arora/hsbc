package DaoImpl;
/* Author: Diviyansha Agarwal
 * Description: The class implements the interface ApparelDao and provides the definition to the functions. .
 */

import java.util.ArrayList;
import java.util.Collections;

import dao.ApparelDao;
import exceptions.InvalidCategoryException;
import exceptions.ItemCodeAlreadyExistsException;
import model.Apparel;
import model.FoodItems;

public class ApparelImpl implements ApparelDao {
	private ArrayList<Apparel> apparelItems=new ArrayList<Apparel>();
	Apparel apparel;
	

	@Override
	public String toString() {
		return "ApparelImpl [apparelItems=" + apparelItems + ", apparel=" + apparel + "]";
	}

	public ArrayList<Apparel> getApparelItems() {
		return apparelItems;
	}

	public void setApparelItems(ArrayList<Apparel> apparelItems) {
		this.apparelItems = apparelItems;
	}

	public Apparel getApparel() {
		return apparel;
	}

	public void setApparel(Apparel apparel) {
		this.apparel = apparel;
	}
	/*This function:
	 * 1. Takes the argument as an object.
	 * 2. Then check that whether there are values or not in the arraylist.
	 * 3..Then it checks that whether the item code exists or not and throws the exception.
	 * 4. Then it adds it to the array list.
	 * 
	 */

	@Override
	public void addNewItem(Apparel apparel) throws ItemCodeAlreadyExistsException {
		// TODO Auto-generated method stub
		if(apparelItems.isEmpty()) {
			System.out.println("No Items.");
		}
		else {
			for (Apparel apparell1 : apparelItems) {
				if(apparell1.getItemCode()==apparell1.getItemCode()) {
					throw new ItemCodeAlreadyExistsException("This item code has already been registered.Please try");
					break;
				}
				
			}
			apparelItems.add(apparel);
			Collections.sort(apparel);
		}
		
	}
	/* 1. It takes arraylist and category as arguments.
	 * 2. Then it checks if the category matches to the argument the it prints the top 3 elements 
	 * otherwise throws a request.
	 */

	@Override
	public void retrievedata(ArrayList<Apparel> apparel, String category) throws InvalidCategoryException {
		// TODO Auto-generated method stub
		int count=0;
		if(category.equalsIgnoreCase("apparel"))
		{
		for (Apparel apparel1 : apparelItems) {
			System.out.println(apparel1);
			count++;
			if(count==3)
				break;
		
			
		}
		}
		else {
			throw new InvalidCategoryException("This is not the apt category. Please try again.");
		}
		
		
	}
	

	
}
