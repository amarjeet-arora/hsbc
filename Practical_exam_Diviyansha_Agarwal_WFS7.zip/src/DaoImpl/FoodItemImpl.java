package DaoImpl;
/* Author: Diviyansha Agarwal
 * Description: The class implements the interface FoodItemDao and provides the definition to the functions. .
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dao.FoodItemDao;
import exceptions.InvalidCategoryException;
import exceptions.ItemCodeAlreadyExistsException;
import model.FoodItems;

public class FoodItemImpl implements FoodItemDao {
	//object of the food item class
	private FoodItems food;
	private ArrayList<FoodItems> foodItems=new ArrayList<FoodItems>();
	

	@Override
	public String toString() {
		return "FoodItemImpl [food=" + food + ", foodItems=" + foodItems + "]";
	}

	public FoodItemImpl(FoodItems food, ArrayList<FoodItems> foodItems) {
		super();
		this.food = food;
		this.foodItems = foodItems;
	}

	public FoodItems getFood() {
		return food;
	}

	public void setFood(FoodItems food) {
		this.food = food;
	}

	public ArrayList<FoodItems> getFoodItems() {
		return foodItems;
	}

	public void setFoodItems(ArrayList<FoodItems> foodItems) {
		this.foodItems = foodItems;
	}
	/*This function:
	 * 1. Takes the argument as an object.
	 * 2. Then check that whether there are values or not in the arraylist.
	 * 3..Then it checks that whether the item code exists or not and throws the exception.
	 * 4. Then it adds it to the array list.
	 * 
	 */

	@Override
	public void addNewItem(FoodItems food) throws ItemCodeAlreadyExistsException {
		// TODO Auto-generated method stub
		if(foodItems.isEmpty()) {
			System.out.println("No Food Items.");
		}
		else {
			for (FoodItems foodItems2 : foodItems) {
				if(foodItems2.getItemCode()==food.getItemCode()) {
					throw new ItemCodeAlreadyExistsException("This item code has already been registered.Please try");
					break;
				}
				
			}
			foodItems.add(food);
			Collections.sort(food);
			System.out.println(food);
		}
		
	}
	/* 1. It takes arraylist and category as arguments.
	 * 2. Then it checks if the category matches to the argument the it prints the top 3 elements 
	 * otherwise throws a request.
	 */

	@Override
	public void retrievedata(String category,ArrayList<FoodItems> food) throws InvalidCategoryException {
		// TODO Auto-generated method stub
		int count=0;
		if(category.equalsIgnoreCase("food items"))
		{
		for (FoodItems foodItems : food) {
			System.out.println(foodItems);
			count++;
			if(count==3)
				break;
		
			
		}
		}
		else {
			throw new InvalidCategoryException("This is not the apt category. Please try again.");
		}
		
	}
	

}
