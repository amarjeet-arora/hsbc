package DaoImpl;
/* Author: Diviyansha Agarwal
 * Description: The class implements the interface ElectronicsDao and provides the definition to the functions. .
 */

import java.util.ArrayList;
import java.util.Collections;

import dao.ElectronicsDao;
import exceptions.InvalidCategoryException;
import exceptions.ItemCodeAlreadyExistsException;
import model.Electronics;
import model.FoodItems;

public class ElectronicsImpl implements ElectronicsDao {
	private Electronics electronic;
	private ArrayList<Electronics> electronicItems=new ArrayList<Electronics>();
	

	@Override
	public String toString() {
		return "ElectronicsImpl [electronic=" + electronic + ", electronicItem=" + electronicItems + "]";
	}

	public Electronics getElectronic() {
		return electronic;
	}

	public void setElectronic(Electronics electronic) {
		this.electronic = electronic;
	}

	public ArrayList<Electronics> getElectronicItems() {
		return electronicItems;
	}

	public void setElectronicItems(ArrayList<Electronics> electronicItem) {
		this.electronicItems = electronicItems;
	}
	/*This function:
	 * 1. Takes the argument as an object.
	 * 2. Then check that whether there are values or not in the arraylist.
	 * 3..Then it checks that whether the item code exists or not and throws the exception.
	 * 4. Then it adds it to the array list.
	 * 
	 */

	@Override
	public void addNewItem(Electronics electronicItem) throws ItemCodeAlreadyExistsException {
		
		// TODO Auto-generated method stub
		if(electronicItems.isEmpty()) {
			System.out.println("No Electronic Items.");
		}
		else {
			for (Electronics electronics : electronicItems) {
				if(electronics.getItemCode()==electronicItem.getItemCode()) {
					throw new ItemCodeAlreadyExistsException("This item code has already been registered.Please try");
					break;
				}
				
			}
			
				
			}
			electronicItems.add(electronicItem);
			Collections.sort(electronicItems);
		}
		
	/* 1. It takes arraylist and category as arguments.
	 * 2. Then it checks if the category matches to the argument the it prints the top 3 elements 
	 * otherwise throws a request.
	 */

	@Override
	public void retrievedata(ArrayList<Electronics> electronicItem, String category) throws InvalidCategoryException {
		// TODO Auto-generated method stub
		int count=0;
		if(category.equalsIgnoreCase("Electronics")){
			for (Electronics electronics : electronicItem) {
				System.out.println(electronics);
				count++;
				if(count==3) {
					break;
				}
				
			}
		}
		else {
			throw new InvalidCategoryException("This is not the apt category. Please try again.");
		}
	}

}
