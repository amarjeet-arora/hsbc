package dao;
/* Author: Diviyansha Agarwal
 * Description: The interface declares all the methods..
 */

import java.util.ArrayList;

import exceptions.InvalidCategoryException;
import exceptions.ItemCodeAlreadyExistsException;
import model.Apparel;


public interface ApparelDao {
	public void addNewItem(Apparel apparel) throws ItemCodeAlreadyExistsException;
	public void retrievedata(ArrayList<Apparel> apparel,String category) throws InvalidCategoryException;
}
