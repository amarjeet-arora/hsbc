package dao;
/* Author: Diviyansha Agarwal
 * Description: The interface declares all the methods..
 */

import java.util.ArrayList;

import exceptions.InvalidCategoryException;
import exceptions.ItemCodeAlreadyExistsException;
import model.FoodItems;

public interface FoodItemDao {
	public void addNewItem(FoodItems food) throws ItemCodeAlreadyExistsException;
	public void retrievedata(String category, ArrayList<FoodItems> food) throws InvalidCategoryException;

}
