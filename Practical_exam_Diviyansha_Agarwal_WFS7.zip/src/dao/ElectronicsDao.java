package dao;
/* Author: Diviyansha Agarwal
 * Description: The interface declares all the methods..
 */

import java.util.ArrayList;

import exceptions.InvalidCategoryException;
import exceptions.ItemCodeAlreadyExistsException;
import model.Electronics;


public interface ElectronicsDao {
	public void addNewItem(Electronics electronicItem) throws ItemCodeAlreadyExistsException;
	public void retrievedata(ArrayList<Electronics> electronicItem,String category) throws InvalidCategoryException;

}
