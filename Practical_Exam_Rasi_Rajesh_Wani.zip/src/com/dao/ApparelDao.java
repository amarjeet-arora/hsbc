package com.dao;

import java.util.ArrayList;

import com.entity.Apparel;
import com.exception.ItemCodeAlreadyExist;
import com.exception.ItemNotFoundException;

/*Doa interface for Apparel has to methods
 * addApparelItem() - takes the FoodItems object and returns the object of Apparel
 * getApparelItem() - takes the itemCode and returns the object of Apparel
 */
public interface ApparelDao {

	public Apparel addApparelItem(Apparel aaparel) throws ItemCodeAlreadyExist;
	public Apparel getApparelItem(int itemCode) throws ItemNotFoundException;
}
