package com.dao;

import java.util.ArrayList;

import com.entity.FoodItems;
import com.exception.ItemCodeAlreadyExist;
import com.exception.ItemNotFoundException;

/*Doa interface for FoodItems has two methods
 * addFoodItem() - takes the FoodItems object and returns the object of FoodItems
 * getFoodItem() - takes the itemCode and returns the object of FoodItems
 */

public interface FoodItemsDao 
{
	public FoodItems addFoodItem(FoodItems food) throws ItemCodeAlreadyExist;
	public FoodItems getFoodItem(int itemCode) throws ItemNotFoundException;
 
}
