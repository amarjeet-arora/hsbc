package com.dao;

import java.util.ArrayList;

import com.entity.Electronics;
import com.exception.ItemCodeAlreadyExist;
import com.exception.ItemNotFoundException;

/*Doa interface for Electronics has two methods
 * addElectronicsItem() - takes the electronics object and returns the object of Electronics
 * getElectronicsItem() - takes the itemCode and returns the object of Electronics
 */
public interface ElectronicsDao {

	public Electronics addElectronicsItem(Electronics electronics) throws ItemCodeAlreadyExist;
	public Electronics getElectronicsItem(int itemCode) throws ItemNotFoundException;
}
