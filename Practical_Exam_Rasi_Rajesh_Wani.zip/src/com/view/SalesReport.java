package com.view;

public class SalesReport {

	public static void main(String[] args)
	{
		
	}

}
