package com.exception;

public class ItemCodeAlreadyExist extends Exception {
	
	public ItemCodeAlreadyExist() {
		super();
	}
	
	public ItemCodeAlreadyExist(String message) {
		super(message);
	}

}
