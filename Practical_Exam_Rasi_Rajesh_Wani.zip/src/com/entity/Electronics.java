package com.entity;

import java.util.Comparator;

public class Electronics implements Comparator<Electronics>
{
	int itemCode;
	String itemName;
	double unitPrice;
	int warrantyInMonths;
	int quantity;
	
	public Electronics(int itemCode, String itemName, double unitPrice, int warrantyInMonths, int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.warrantyInMonths = warrantyInMonths;
		this.quantity = quantity;
	}

	//getter and setter methods
	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getWarrantyInMonths() {
		return warrantyInMonths;
	}

	public void setWarrantyInMonths(int warrantyInMonths) {
		this.warrantyInMonths = warrantyInMonths;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	//displays the object
	@Override
	public String toString() {
		return "Electronics [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", warrantyInMonths=" + warrantyInMonths + ", quantity=" + quantity + "]";
	}

		//compares object by quantity
		@Override
		public int compare(Electronics e1, Electronics e2) 
		{
			return e1.getQuantity()-e2.getQuantity();
		}
	
	
}
