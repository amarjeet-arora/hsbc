package com.entity;

import java.util.Comparator;
import java.util.Date;

public class FoodItems  implements Comparator<FoodItems>
{
	int itemCode;
	String itemName;
	double unitPrice;
	Date manufactureDate;
	Date expiryDate;
	boolean vegetarian;
	int quantity;
	
	
	public FoodItems(int itemCode, String itemName, double unitPrice, Date manufactureDate, Date expiryDate,
			boolean vegetarian, int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
		this.vegetarian = vegetarian;
		this.quantity = quantity;
	}
	
	//getter and setter methods
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Date getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public boolean isVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	//compares object by quantity
	@Override
	public int compare(FoodItems e1, FoodItems e2) 
	{
		return e1.getQuantity()-e2.getQuantity();
	}

	//displays the object
	@Override
	public String toString() {
		return "FoodItems [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", manufactureDate=" + manufactureDate + ", expiryDate=" + expiryDate + ", vegetarian=" + vegetarian
				+ ", quantity=" + quantity + "]";
	}
	
}
