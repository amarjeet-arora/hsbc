package com.entity;

import java.util.Comparator;


/*
 * Apparel class contains Apparel
 */
public class Apparel implements Comparator<Apparel>
{
	int itemCode;
	String itemName;
	double unitPrice;
	double size;
	boolean material;
	int quantity;
	
	public Apparel(int itemCode, String itemName, double unitPrice, double size, boolean material, int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.size = size;
		this.material = material;
		this.quantity = quantity;
	}
	
	//getter and setter methods
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public boolean getMaterial() {
		return material;
	}
	public void setMaterial(boolean material) {
		this.material = material;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	//displays the object
	@Override
	public String toString() {
		return "Apparel [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", size="
				+ size + ", material=" + material + ", quantity=" + quantity + "]";
	}

	//compares object by quantity
	@Override
	public int compare(Apparel e1, Apparel e2) 
	{
		return e1.getQuantity()-e2.getQuantity();
	}
	
}
