package com.daoimpl;

import java.util.HashMap;
import java.util.Map;

import com.dao.ElectronicsDao;
import com.entity.Apparel;
import com.entity.Electronics;
import com.exception.ItemCodeAlreadyExist;
import com.exception.ItemNotFoundException;

/*
 * Class ElectroicsDaoImpl implements ElectronicsDao 
 */
public class ElectroicsDaoImpl  implements ElectronicsDao
{
	private Map<Integer, Electronics> electronicsItems = new HashMap<Integer, Electronics>();
	
	//adds the item and throws exception if Item is already there
	@Override
	public Electronics addElectronicsItem(Electronics electronics) throws ItemCodeAlreadyExist
	{
		if(electronicsItems.containsKey(electronics.getItemCode())) 
		{
			throw new ItemCodeAlreadyExist("Item Code Already Exist !!");
		}
		electronicsItems.put(electronics.getItemCode(), electronics);
		return electronics;
	}

	//gets the item and throws exception if Item is not there
	@Override
	public Electronics getElectronicsItem(int itemCode) throws ItemNotFoundException 
	{
		Electronics electronics = electronicsItems.get(itemCode);
		if(electronics == null)
		{
			throw new ItemNotFoundException("Item not found");
		}
		return electronics;	
	}

}
