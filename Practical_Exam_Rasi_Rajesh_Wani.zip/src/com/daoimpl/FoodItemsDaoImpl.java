package com.daoimpl;

import java.util.HashMap;
import java.util.Map;

import com.dao.FoodItemsDao;
import com.entity.FoodItems;
import com.exception.ItemCodeAlreadyExist;
import com.exception.ItemNotFoundException;

/*
 * Class FoodItemsDaoImpl implements FoodItemsDao 
 */
public class FoodItemsDaoImpl implements FoodItemsDao
{
	private Map<Integer, FoodItems> foodItems = new HashMap<Integer, FoodItems>();

	//adds the item and throws exception if Item is already there
	@Override
	public FoodItems addFoodItem(FoodItems food) throws ItemCodeAlreadyExist
	{
		if(foodItems.containsKey(food.getItemCode())) 
		{
			throw new ItemCodeAlreadyExist("Item Code Already Exist !!");
		}
		foodItems.put(food.getItemCode(), food);
		return food;
	}

	//gets the item and throws exception if Item is not there
	@Override
	public FoodItems getFoodItem(int itemCode) throws ItemNotFoundException 
	{
		FoodItems food = foodItems.get(itemCode);
		if(food == null)
		{
			throw new ItemNotFoundException("Item not found");
		}
		return food;
	}
}
