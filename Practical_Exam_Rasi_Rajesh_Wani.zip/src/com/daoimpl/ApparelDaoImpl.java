package com.daoimpl;

import java.util.HashMap;
import java.util.Map;

import com.dao.ApparelDao;
import com.entity.Apparel;
import com.exception.ItemCodeAlreadyExist;
import com.exception.ItemNotFoundException;

/*
 * Class ApprelDaoImpl implements ApparelDao 
 */
public class ApparelDaoImpl implements ApparelDao
{
	private Map<Integer, Apparel> apparelItems = new HashMap<Integer, Apparel>();

	//adds the item and throws exception if Item is already there
	@Override
	public Apparel addApparelItem(Apparel aaparel) throws ItemCodeAlreadyExist 
	{
		if(apparelItems.containsKey(aaparel.getItemCode())) 
		{
			throw new ItemCodeAlreadyExist("Item Code Already Exist !!");
		}
		apparelItems.put(aaparel.getItemCode(), aaparel);
		return aaparel;
	}

	//gets the item and throws exception if Item is not there
	@Override
	public Apparel getApparelItem(int itemCode) throws ItemNotFoundException 
	{
		Apparel aaparel = apparelItems.get(itemCode);
		if(aaparel == null)
		{
			throw new ItemNotFoundException("Item not found");
		}
		return aaparel;	
	}
}
