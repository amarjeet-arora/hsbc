package com.hsbc.test.daoImpl;

import java.util.ArrayList;
import java.util.Collections;

import com.hsbc.test.dao.FoodItemsDao;
import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.FoodItemCompareByQuantity;
import com.hsbc.test.model.FoodItems;

public class FoodItemsDaoImpl implements FoodItemsDao {

	ArrayList<FoodItems> foodItems = new ArrayList<FoodItems>();
	
	@Override
	public void saveProduct(FoodItems foodItem) {
		// TODO Auto-generated method stub
		foodItems.add(foodItem);
	}
	
	
	@Override
	public void getHighestSales() throws NoDataHereException{
		// If this category does not have any data it will throw an error 
		if(foodItems.size()<1)
		{
			// Throw an Custom Exception
			throw new NoDataHereException("Record does not exist...");	
		}
		else {
		
			Collections.sort(foodItems, new FoodItemCompareByQuantity());
			
			for(int i = 0; i < 3; i++)
			{
				// If this category has less 3 records then it will sort those records and display those only
				if(i<foodItems.size())
					System.out.println(foodItems.get(i));
			}
		}

	}
}
