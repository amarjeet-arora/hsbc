package com.hsbc.test.daoImpl;

import java.util.ArrayList;
import java.util.Collections;

import com.hsbc.test.dao.ApparelDao;
import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.Apparel;
import com.hsbc.test.model.ApparelCompareByQuantity;

public class ApparelDaoImpl implements ApparelDao {

	ArrayList<Apparel> apparels=new ArrayList<Apparel>();

	
	@Override
	public void getHighestSales() throws NoDataHereException {
		// If this category does not have any data it will throw an error 
		if(apparels.size()<1)
			{
				// Throw an Custom Exception
				throw new NoDataHereException("Record does not exist...");	
			}
		else {
			
			Collections.sort(apparels, new ApparelCompareByQuantity());
			
			for(int i = 0; i < 3; i++)
			{
				// If this category has less 3 records then it will sort those records and display those only
				if(i<apparels.size())
					System.out.println(apparels.get(i));
			}
		}
	}

	@Override
	public void saveProduct(Apparel apparel) {
		// TODO Auto-generated method stub
		apparels.add(apparel);
	}

}
