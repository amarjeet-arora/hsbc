package com.hsbc.test.daoImpl;

import java.util.ArrayList;
import java.util.Collections;

import com.hsbc.test.dao.ElectronicsDao;
import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.Electronics;
import com.hsbc.test.model.ElectronicsComparByQuantity;

public class ElectronicsDaoImpl  implements ElectronicsDao{
	ArrayList<Electronics> electronics=new ArrayList<Electronics>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void saveProduct(Electronics electronic) {
		// TODO Auto-generated method stub
		electronics.add(electronic);
	}
	
	@Override
	public void getHighestSales() throws NoDataHereException{
		// If this category does not have any data it will throw an error 
		if(electronics.size()<1)
		{
			// Throw an Custom Exception
			throw new NoDataHereException("Record does not exist...");	
		}
		else {
			
			Collections.sort(electronics, new ElectronicsComparByQuantity());
			
			for(int i = 0; i < 3; i++)
			{
				// If this category has less 3 records then it will sort those records and display those only
				if(i<electronics.size())
					System.out.println(electronics.get(i));
			}
		}
	}

}
