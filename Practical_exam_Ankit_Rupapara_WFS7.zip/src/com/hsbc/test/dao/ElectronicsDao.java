package com.hsbc.test.dao;

import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.Electronics;

public interface ElectronicsDao {
	void getHighestSales() throws NoDataHereException;

	void saveProduct(Electronics electronic);
}
