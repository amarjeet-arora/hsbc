package com.hsbc.test.dao;

import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.Apparel;

public interface ApparelDao {
	void saveProduct(Apparel apparel);
	void getHighestSales() throws NoDataHereException;
}
 