package com.hsbc.test.dao;

import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.FoodItems;

public interface FoodItemsDao {

	void getHighestSales() throws NoDataHereException;

	void saveProduct(FoodItems foodItem);
	
}
