package com.hsbc.test.view;

import java.util.Scanner;

import com.hsbc.test.dao.ApparelDao;
import com.hsbc.test.dao.ElectronicsDao;
import com.hsbc.test.dao.FoodItemsDao;
import com.hsbc.test.daoImpl.ApparelDaoImpl;
import com.hsbc.test.daoImpl.ElectronicsDaoImpl;
import com.hsbc.test.daoImpl.FoodItemsDaoImpl;
import com.hsbc.test.exception.NoDataHereException;
import com.hsbc.test.model.Apparel;

// Driver Class
public class Client {

	// Gets access to DAO implementation
	static FoodItemsDao fid = new FoodItemsDaoImpl();
	static ApparelDao ad =new ApparelDaoImpl();
	static ElectronicsDao ed = new ElectronicsDaoImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter the code to get report : \n"
				+ "1 : Food Items \n"
				+ "2 : Apparels \n"
				+ "3 : Electronics \n");
		
		Scanner scanner = new Scanner(System.in);
		

		// Add some data to apparels
		ad.saveProduct(new Apparel(104, "ApparelDesign3", 1000, 15, 30, "Cotton3"));
		ad.saveProduct(new Apparel(101, "ApparelDesign1", 600, 11, 32, "Cotton1"));
		ad.saveProduct(new Apparel(102, "ApparelDesign2", 700, 12, 34, "Cotton2"));
		ad.saveProduct(new Apparel(103, "ApparelDesign3", 1000, 13, 30, "Cotton3"));

	
		// Choice to get records
  		int selectionCode = scanner.nextInt();
		
		switch (selectionCode) {
		case 1 :
			// goes to Food Items Implementation
			try {
				fid.getHighestSales();
			} catch (NoDataHereException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage() );
			}
			break;
		case 2 :
			// goes to Apparels Implementation
			try {
				ad.getHighestSales();
			} catch (NoDataHereException e) {
				// TODO Auto-generated catch block

				System.out.println(e.getMessage() );
			}
			break;
		case 3 :
			// goes to Electronics Implementation
			try {
				ed.getHighestSales();
			} catch (NoDataHereException e) {
				// TODO Auto-generated catch block

				System.out.println(e.getMessage() );
			}
			break;
		default :
			System.out.println("Wrong selection to get report !!"); 
		}

		scanner.close();
		
		
	}

}
