package com.hsbc.test.exception;

public class NoDataHereException extends Exception {

	//Give error that no data is entered in selected option
	private static final long serialVersionUID = 8067199570870803511L;
	public NoDataHereException() {
		super();
	}
	public NoDataHereException(String message){
		super(message);
	}
}
