package com.hsbc.test.model;

import java.util.Comparator;

public class ApparelCompareByQuantity implements Comparator<Apparel> {

	
	@Override
	public int compare(Apparel o1, Apparel o2) {
		// TODO Auto-generated method stub
		return o2.getQuantity() - o1.getQuantity();
	}

}
