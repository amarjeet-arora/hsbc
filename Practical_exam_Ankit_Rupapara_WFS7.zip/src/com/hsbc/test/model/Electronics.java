package com.hsbc.test.model;

public class Electronics extends Item {
	
	int warranty; // in months
	

	public int getWarranty() {
		return warranty;
	}


	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	public Electronics(int itemCode, String itemName, int unitPrice, int quantity, int warranty) {
		super(itemCode, itemName, unitPrice, quantity);
		this.warranty = warranty;
	}


	public Electronics(int itemCode, String itemName, int unitPrice, int quantity) {
		super(itemCode, itemName, unitPrice, quantity);
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public String toString() {
		return "Electronics [ Item Code = " + itemCode + ", Item Name = " + itemName + ", Quantity Sold = " + quantity + ", Warranty(in months) = "
				+ warranty + " ]";
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
