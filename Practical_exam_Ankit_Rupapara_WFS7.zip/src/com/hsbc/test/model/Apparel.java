package com.hsbc.test.model;

public class Apparel extends Item {

	int size;
	String material;
	
	
	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public String getMaterial() {
		return material;
	}


	public void setMaterial(String material) {
		this.material = material;
	}





	@Override
	public String toString() {
		return "Apparel [ Item Code = " + itemCode + ", Item Name = " + itemName + ", Quantity Sold = " + quantity + ", Size=" + size + ", Material = " + material +  " ]";
	}


	public Apparel(int itemCode, String itemName, int unitPrice, int quantity, int size, String material) {
		super(itemCode, itemName, unitPrice, quantity);
		this.size = size;
		this.material = material;
	}


	public Apparel(int itemCode, String itemName, int unitPrice, int quantity) {
		super(itemCode, itemName, unitPrice, quantity);
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
