package com.hsbc.test.model;

import java.util.Comparator;

public class ElectronicsComparByQuantity implements Comparator<Electronics>{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compare(Electronics o1, Electronics o2) {
		// TODO Auto-generated method stub
		return o2.getQuantity() - o1.getQuantity();
	}

}
