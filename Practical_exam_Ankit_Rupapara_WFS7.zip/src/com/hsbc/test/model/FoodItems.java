package com.hsbc.test.model;

import java.util.Date;

public class FoodItems extends Item {

	Date dateofMfg;
	Date dateofExpiry;
	boolean vegetarian;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public Date getDateofMfg() {
		return dateofMfg;
	}

	public void setDateofMfg(Date dateofMfg) {
		this.dateofMfg = dateofMfg;
	}

	public Date getDateofExpiry() {
		return dateofExpiry;
	}

	public void setDateofExpiry(Date dateofExpiry) {
		this.dateofExpiry = dateofExpiry;
	}

	public boolean isVegetarian() {
		return vegetarian;
	}

	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}

	public FoodItems(int itemCode, String itemName, int unitPrice, int quantity) {
		super(itemCode, itemName, unitPrice, quantity);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FoodItems [ Item Code = " + itemCode + ", Item Name = " + itemName + ", Quantity Sold = " + quantity + ", Vegetarian = "
				+ vegetarian + " ]";
	}

	

}
