package com.hsbc.test.model;

import java.util.Comparator;

public class FoodItemCompareByQuantity implements Comparator<FoodItems>{

	@Override
	public int compare(FoodItems o1, FoodItems o2) {
		// TODO Auto-generated method stub
		return o2.quantity - o1.quantity;
	}

}
