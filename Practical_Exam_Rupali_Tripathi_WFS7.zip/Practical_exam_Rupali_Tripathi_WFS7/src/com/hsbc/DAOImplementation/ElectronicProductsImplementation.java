/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the implementation regarding how various manipulations would be done by the store ret
 * retailer on the products of the ELECTRONICS CATEGORY.>
 *
 */
package com.hsbc.DAOImplementation;
//Class definition
import java.util.Collection;
import java.util.HashMap;

import com.hsbc.DAO.ElectronicProducts;
import com.hsbc.DAO.ElectronicProducts;
import com.hsbc.DAO.ElectronicProductsDAO;
import com.hsbc.DAO.ElectronicProductsException;
import com.hsbc.exception.ProductException;
import com.hsbc.model.Product;
//Declaring a HashMap to store electronicsProducts
public class ElectronicProductsImplementation implements ElectronicProductsDAO {
	//Declaring a HashMap to store electronicProducts
	HashMap<Integer, ElectronicProducts> electronicProductMapToStoreValue=new HashMap<Integer, ElectronicProducts>();
	
	
	//Save Product Method
	public void saveProduct(ElectronicProducts p) throws ProductException {
		electronicProductMapToStoreValue.put(p.getProductCode(), p);
	}
	
	//Update Product Method
	@Override
	public Product updateProduct(ElectronicProducts p) throws ElectronicProductsImplementation {
		if(electronicProductMapToStoreValue.get(p.getProductId())!=null)
			electronicProductMapToStoreValue.put(p.getProductId(),p);
		else
			throw new ElectronicProductsException("Product does not exist to be updated..");
		return p;
	}
	
	//Delete Product Method
	@Override
	public void deleteProduct(ElectronicProducts p) throws ElectronicProductsException {
		if(electronicProductMapToStoreValue.get(p.getProductId())!=null)
			electronicProductMapToStoreValue.remove(p.getProductId());
		else
			throw new ElectronicProductsException("Product does not exist to be deleted");
	}

	@Override
	public Collection<ElectronicProducts> findProducts() throws ElectronicProductsException {
		return electronicProductMapToStoreValue.values();
	}

	@Override
	public ElectronicProducts findProductById(int productCode) throws ElectronicProductsException {
		if(electronicProductMapToStoreValue.get(productId)!=null)
			return (ElectronicProducts)product.get(productCode);
		else
			throw new ElectronicProductsException("Product does not exist");
	}


}
