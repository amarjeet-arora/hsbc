/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the implementation regarding how various manipulations would be done by the store ret
 * retailer on the products of the APPAREL CATEGORY.>
 *
 */
package com.hsbc.DAOImplementation;

import java.util.Collection;
import java.util.HashMap;


import com.hsbc.DAO.ApparelProducts;
import com.hsbc.DAO.ApparelProductsDAO;
import com.hsbc.DAO.ApparelProductsException;
import com.hsbc.exception.ProductException;
import com.hsbc.model.Product;


//Class definition
public class ApparelProductsImplementation implements ApparelProductsDAO {
	
	//Declaring a HashMap to store apparelProducts
	HashMap<Integer, ApparelProducts> apparelProductsMap=new HashMap<Integer, ApparelProducts>();
	
	//Save Product Method
	@Override
	public void saveProduct(ApparelProducts p) throws ApparelProductException {
		apparelProductsMap.put(p.getProductCode(), p);
	}

	@Override
	//Update Product Method
	public Product updateProduct(ApparelProducts p) throws ApparelProductsImplementation {
		if(apparelProductsMap.get(p.getProductId())!=null)
			apparelProductsMap.put(p.getProductId(),p);
		else
			throw new ApparelProductsException("Product does not exist to be updated..");
		return p;
	}

	@Override
	//Delete Product method
	public void deleteProduct(ApparelProducts p) throws ApparelProductsException {
		if(apparelProductsMap.get(p.getProductId())!=null)
			apparelProductsMap.remove(p.getProductId());
		else
			throw new ApparelProductsException("Product does not exist to be deleted");
	}

	@Override
	//dispalyinhg all the products
	public Collection<ApparelProducts> findProducts() throws ApparelProductsException {
		return ApparelProductsMap.values();
	}

	@Override
	//finding product by id
	public ApparelProducts findProductById(int productCode) throws ApparelProductsException {
		if(apparelProductsMap.get(productId)!=null)
			return (ApparelProducts)product.get(productCode);
		else
			throw new ApparelProductsException("Product does not exist");
	}


}
