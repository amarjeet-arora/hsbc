/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the implementation regarding how various manipulations would be done by the store ret
 * retailer on the products of the FOOD CATEGORY.>
 *
 */
package com.hsbc.DAOImplementation;

import java.util.Collection;

import java.util.HashMap;

import com.hsbc.DAO.FoodFoodProducts;
import com.hsbc.DAO.FoodProducts;
import com.hsbc.DAO.FoodProductsDAO;
import com.hsbc.DAO.FoodProductsException;
import com.hsbc.exception.ProductException;
import com.hsbc.model.Product;

//Class definition
public class FoodProductsImplementation implements FoodProductsDAO {
	//Declaring a HashMap to store foodProducts
	HashMap<Integer, FoodProducts> foodProductsMap=new HashMap<Integer, FoodProducts>();

	public void saveProduct(FoodProducts p) throws ProductException {
		foodProductMapToStoreValue.put(p.getProductCode(), p);
	}

	@Override
	//Update Product Method
	public Product updateProduct(FoodProducts p) throws FoodProductsImplementation {
		if(foodProductsMap.get(p.getProductId())!=null)
			foodProductsMap.put(p.getProductId(),p);
		else
			throw new FoodProductsException("Product does not exist to be updated..");
		return p;
	}

	@Override
	//Delete Product Method
	public void deleteProduct(FoodProducts p) throws FoodProductsException {
		if(foodProductsMap.get(p.getProductId())!=null)
			foodProductsMap.remove(p.getProductId());
		else
			throw new FoodProductsException("Product does not exist to be deleted");
	}

	@Override
	//Finding Product Method
	public Collection<FoodProducts> findProducts() throws FoodProductsException {
		return foodProductsMap.values();
	}

	@Override
	//Finding Products By Id Method 
	public FoodProducts findProductById(int productCode) throws FoodProductsException {
		if(foodProductsMap.get(productId)!=null)
			return (FoodProducts)product.get(productCode);
		else
			throw new FoodProductsException("Product does not exist");
	}


}
