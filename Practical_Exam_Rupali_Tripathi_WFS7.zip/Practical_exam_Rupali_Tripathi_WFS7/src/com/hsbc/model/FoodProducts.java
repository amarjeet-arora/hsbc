/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the products of the FOOD CATEGORY.>
 */
package com.hsbc.model;

/**
 * @author RUPALI TRIPATHI
 *
 */
//Class file that defines the entity/properties of the Apparel products
public class FoodProducts {
	int productCode,quantity;
	String name, dateOfManufacture, dateOfExpiry;
	double unitPrice;
	boolean vegetarian;
	
	//default Constructor
	public FoodProducts() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//overloaded constructor to initialize the values received from end USER(DSR opearator here)
	public FoodProducts(int productCode, int quantity, String name, String dateOfManufacture, String dateOfExpiry,
			double unitPrice, boolean vegetarian) {
		super();
		this.productCode = productCode;
		this.quantity = quantity;
		this.name = name;
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpiry = dateOfExpiry;
		this.unitPrice = unitPrice;
		this.vegetarian = vegetarian;
	}
	
	//getter and setter methods to get and set the values
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public String getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(String dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public boolean isVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
	
	//HashCode Implementation
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dateOfExpiry == null) ? 0 : dateOfExpiry.hashCode());
		result = prime * result + ((dateOfManufacture == null) ? 0 : dateOfManufacture.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + productCode;
		result = prime * result + quantity;
		long temp;
		temp = Double.doubleToLongBits(unitPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (vegetarian ? 1231 : 1237);
		return result;
	}
	
	//EqualsTo Implementation
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FoodProducts other = (FoodProducts) obj;
		if (dateOfExpiry == null) {
			if (other.dateOfExpiry != null)
				return false;
		} else if (!dateOfExpiry.equals(other.dateOfExpiry))
			return false;
		if (dateOfManufacture == null) {
			if (other.dateOfManufacture != null)
				return false;
		} else if (!dateOfManufacture.equals(other.dateOfManufacture))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (productCode != other.productCode)
			return false;
		if (quantity != other.quantity)
			return false;
		if (Double.doubleToLongBits(unitPrice) != Double.doubleToLongBits(other.unitPrice))
			return false;
		if (vegetarian != other.vegetarian)
			return false;
		return true;
	}
	@Override
	
	//The string method that will help toprint strings in human readable form
	public String toString() {
		return "FoodProducts [productCode=" + productCode + ", quantity=" + quantity + ", name=" + name
				+ ", dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", unitPrice="
				+ unitPrice + ", vegetarian=" + vegetarian + "]";
	}
	
	

}
