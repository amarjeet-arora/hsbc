/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the products of the ELECTRONICS CATEGORY.>
 */
package com.hsbc.model;

/**
 * @author RUPALI TRIPATHI
 *
 */
//Class file that defines the entity/properties of the Apparel products
public class ElectronicProducts {
	int productCode,quantity,warrantyInMonths;
	String name, dateOfManufacture;
	double unitPrice;
	public ElectronicProducts() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//overloaded constructor to initialize the values received from end USER(DSR opearator here)
	public ElectronicProducts(int productCode, int quantity, int warrantyInMonths, String name,
			String dateOfManufacture, double unitPrice) {
		super();
		this.productCode = productCode;
		this.quantity = quantity;
		this.warrantyInMonths = warrantyInMonths;
		this.name = name;
		this.dateOfManufacture = dateOfManufacture;
		this.unitPrice = unitPrice;
	}
	
	//Getter and Setter methods to get and set the values
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getWarrantyInMonths() {
		return warrantyInMonths;
	}
	public void setWarrantyInMonths(int warrantyInMonths) {
		this.warrantyInMonths = warrantyInMonths;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	//HashCode Implementation
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dateOfManufacture == null) ? 0 : dateOfManufacture.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + productCode;
		result = prime * result + quantity;
		long temp;
		temp = Double.doubleToLongBits(unitPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + warrantyInMonths;
		return result;
	}
	
	//EqualsTo Implementation
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ElectronicProducts other = (ElectronicProducts) obj;
		if (dateOfManufacture == null) {
			if (other.dateOfManufacture != null)
				return false;
		} else if (!dateOfManufacture.equals(other.dateOfManufacture))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (productCode != other.productCode)
			return false;
		if (quantity != other.quantity)
			return false;
		if (Double.doubleToLongBits(unitPrice) != Double.doubleToLongBits(other.unitPrice))
			return false;
		if (warrantyInMonths != other.warrantyInMonths)
			return false;
		return true;
	}
	
	//This method will help in retrieval of the products in user readable format
	@Override
	public String toString() {
		return "ElectronicProducts [productCode=" + productCode + ", quantity=" + quantity + ", warrantyInMonths="
				+ warrantyInMonths + ", name=" + name + ", dateOfManufacture=" + dateOfManufacture + ", unitPrice="
				+ unitPrice + "]";
	}
	
}
