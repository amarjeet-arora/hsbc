/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the products of the APPAREL CATEGORY.>
 */
package com.hsbc.model;
//Class file that defines the entity/properties of the Apparel products
public class ApparelProducts {
	
	//Properties of the apparel Products
	int productCode,quantity,size;
	String name,material;
	double unitPrice;
	
	//default constructor
	public ApparelProducts() {
		super();
		// TODO Auto-generated constructor stub
	}

	//overloaded constructor to initialize the values received from end USER(DSR opearator here)
	public ApparelProducts(int productCode, int quantity, int size, String name, String material, double unitPrice) {
		super();
		this.productCode = productCode;
		this.quantity = quantity;
		this.size = size;
		this.name = name;
		this.material = material;
		this.unitPrice = unitPrice;
	}

	//GEtter and Seeter methods to get and set the values
	
	public int getProductCode() {
		return productCode;
	}


	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMaterial() {
		return material;
	}


	public void setMaterial(String material) {
		this.material = material;
	}


	public double getUnitPrice() {
		return unitPrice;
	}


	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	//HashCode Implementation
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((material == null) ? 0 : material.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + productCode;
		result = prime * result + quantity;
		result = prime * result + size;
		long temp;
		temp = Double.doubleToLongBits(unitPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	//EqualsTo Implementation
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApparelProducts other = (ApparelProducts) obj;
		if (material == null) {
			if (other.material != null)
				return false;
		} else if (!material.equals(other.material))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (productCode != other.productCode)
			return false;
		if (quantity != other.quantity)
			return false;
		if (size != other.size)
			return false;
		if (Double.doubleToLongBits(unitPrice) != Double.doubleToLongBits(other.unitPrice))
			return false;
		return true;
	}

	//This method will help in retrieval of the products in user readable format
	@Override
	public String toString() {
		return "ApparelProducts [productCode=" + productCode + ", quantity=" + quantity + ", size=" + size + ", name="
				+ name + ", material=" + material + ", unitPrice=" + unitPrice + "]";
	}
	
	
	
	

}
