/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the various exceptions/alternate flow that would be taken in case something
 * goes wrong during manipulation with the products of the APPAREL CATEGORY.>
 */
package com.hsbc.exception;

public class ApparelProductsException extends Exception {

	public ApparelProductsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApparelProductsException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ApparelProductsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ApparelProductsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ApparelProductsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
