/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a class that defines the various exceptions/alternate flow that would be taken in case something
 * goes wrong during manipulation with the products of the FOOD CATEGORY.>
 */

package com.hsbc.exception;

public class FoodProductsException extends Exception {

	public FoodProductsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FoodProductsException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public FoodProductsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public FoodProductsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public FoodProductsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
