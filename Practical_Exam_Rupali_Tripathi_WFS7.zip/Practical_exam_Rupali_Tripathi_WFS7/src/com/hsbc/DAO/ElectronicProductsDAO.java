/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a interface that defines the outline to manipulate with the CATEGORY:Electronic Products>
 *
 */
package com.hsbc.DAO;
import java.util.Collection;

import com.hsbc.exception.ElectronicProductsException;
import com.hsbc.model.ElectronicProducts;

//Interface to declare methods for ApparelProductsDAO
public interface ElectronicProductsDAO {
	
	//Methods of the Interface
	void saveElectronicProducts(ElectronicProducts p) throws ElectronicProductsException;
	ElectronicProducts updateElectronicProducts(ElectronicProducts p) throws ElectronicProductsException;
	void deleteElectronicProducts(ElectronicProducts p) throws ElectronicProductsException;
	Collection<ElectronicProducts> findElectronicProductss() throws ElectronicProductsException;
	ElectronicProducts findElectronicProductsById(int ElectronicProductsId) throws ElectronicProductsException;

}
