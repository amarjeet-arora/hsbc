/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a interface that defines the outline to manipulate with the CATEGORY:Apparel Products>
 *
 */
package com.hsbc.DAO;

import java.util.Collection;

import com.hsbc.exception.ApparelProductsException;
import com.hsbc.model.ApparelProducts;

//Interface to declare methods for ApparelProductsDAO
public interface ApparelProductsDAO {

	//Methods of the Interface
	
	void saveApparelProducts(ApparelProducts p) throws ApparelProductsException;
	ApparelProducts updateApparelProducts(ApparelProducts p) throws ApparelProductsException;
	void deleteApparelProducts(ApparelProducts p) throws ApparelProductsException;
	Collection<ApparelProducts> findApparelProductss() throws ApparelProductsException;
	ApparelProducts findApparelProductsById(int ApparelProductsId) throws ApparelProductsException;
}
