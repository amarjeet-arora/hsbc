/**
 * Author: <RUPALI TRIPATHI>
 * Purpose: <This is a interface that defines the outline to manipulate with the CATEGORY:Food Products>
 *
 */
package com.hsbc.DAO;

import java.util.Collection;

import com.hsbc.exception.FoodProductsException;
import com.hsbc.model.FoodProducts;

//Interface to declare methods for ApparelProductsDAO
public interface FoodProductsDAO {

	//Methods of the Interface
	void saveFoodProducts(FoodProducts p) throws FoodProductsException;
	FoodProducts updateFoodProducts(FoodProducts p) throws FoodProductsException;
	void deleteFoodProducts(FoodProducts p) throws FoodProductsException;
	Collection<FoodProducts> findFoodProductss() throws FoodProductsException;
	FoodProducts findFoodProductsById(int FoodProductsId) throws FoodProductsException;
}
