/**
 * 
 */
package com.main;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

import com.entities.Apparel;
import com.entities.Electronics;
import com.entities.FoodItems;
import com.exceptions.NoSalesException;

/**
 * @author Jayesh
 *
 */
public class SalesReportGeneration {
	
	static Scanner sc = new Scanner(System.in);
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Apparel a1 = new Apparel(101, "Shirt", 30, "Large", "Cotton", 40);
		Apparel a2 = new Apparel(102, "Pant", 40, "Medium", "Cotton", 50);
		Apparel a3 = new Apparel(103, "Sweater", 30, "Medium", "Woolen", 60);
		Apparel a4 = new Apparel(104, "Socks", 40, "Small", "Woolen", 20);
		Apparel a5 = new Apparel(105, "Sweatpants", 40, "Medium", "Cotton", 70);
		FoodItems f1 = new FoodItems(201, "Milk", 20, "20/10/2020", "25/10/2020", "Yes", 50);
		FoodItems f2 = new FoodItems(202, "Butter", 30, "17/09/2020", "22/10/2021", "Yes", 40);
		FoodItems f3 = new FoodItems(203, "Yogurt", 40, "16/10/2020", "25/10/2020", "Yes", 60);
		FoodItems f4 = new FoodItems(204, "Chicken", 20, "20/09/2020", "25/09/2020", "No", 70);
		Electronics e1 = new Electronics(301, "Mobile", 4500, 12, 20);
		Electronics e2 = new Electronics(302, "Laptop", 17000, 24, 30);
		Electronics e3 = new Electronics(303, "Charger", 8000, 20, 50);
		Electronics e4 = new Electronics(304, "Speakers", 9000, 36, 40);
		ArrayList<Apparel> ala = new ArrayList<Apparel>();
		ArrayList<FoodItems> alf = new ArrayList<FoodItems>();
		ArrayList<Electronics> ale = new ArrayList<Electronics>();
		String flg = "Yes";
		while(flg.equals("Yes")) {
		System.out.println("****************************************************");
		System.out.println("             Sales Report Generation");
		System.out.println("****************************************************");
		System.out.println("Please input the ID for category to generate report( 1 for Apparels | 2 for Electronics | 3 for FoodItems ):");
		int category = sc.nextInt();
		
		 
		switch(category) {
		case 1:
			try {
				ala = a5.getSales();
				for(int i=0;i<3;i++) {
				for(Apparel a:Apparel.tsa) {
					System.out.println(a.toString());
				}}
			} catch (NoSalesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:
			try {
				ale = e4.getSales();
				for(int i=0;i<3;i++) {
					for(Electronics e:Electronics.tse) {
						System.out.println(e.toString());
					}}
			} catch (NoSalesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 3:
			try {
				alf = f4.getSales();
				for(int i=0;i<3;i++) {
					for(FoodItems f:FoodItems.tsf) {
						System.out.println(f.toString());
					}}
			} catch (NoSalesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		System.out.println("Try again?(Yes/No):");
		flg = sc.next();
		
	 }
	}
}
