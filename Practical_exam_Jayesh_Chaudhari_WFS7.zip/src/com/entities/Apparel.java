/**
 * 
 */
package com.entities;

import java.util.ArrayList;
import java.util.TreeSet;

import com.dao.ProductDaoApparel;
import com.exceptions.NoSalesException;

/**
 * @author Jayesh
 *
 */
public class Apparel implements ProductDaoApparel, Comparable<Apparel> {
    
	public static TreeSet<Apparel> tsa = new TreeSet<Apparel>();
	private int itemCode;
	private String itemName;
	private int unitPrice;
	private String size;
	private String material;
	private int quantity;
	/**
	 * 
	 */
	public Apparel() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	/**
	 * 
	 * @param itemCode
	 * @param itemName
	 * @param unitPrice
	 * @param size
	 * @param material
	 * @param quantity
	 */
	public Apparel(int itemCode, String itemName, int unitPrice, String size, String material, int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.size = size;
		this.material = material;
		this.quantity = quantity;
		tsa.add(this);
	}

	/**
	 * @return the itemCode
	 */
	public int getItemCode() {
		return itemCode;
	}

	/**
	 * @param itemCode the itemCode to set
	 */
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * @return the unitPrice
	 */
	public int getUnitPrice() {
		return unitPrice;
	}

	/**
	 * @param unitPrice the unitPrice to set
	 */
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * @return the material
	 */
	public String getMaterial() {
		return material;
	}

	/**
	 * @param material the material to set
	 */
	public void setMaterial(String material) {
		this.material = material;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + itemCode;
		result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
		result = prime * result + ((material == null) ? 0 : material.hashCode());
		result = prime * result + quantity;
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		result = prime * result + unitPrice;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparel other = (Apparel) obj;
		if (itemCode != other.itemCode)
			return false;
		if (itemName == null) {
			if (other.itemName != null)
				return false;
		} else if (!itemName.equals(other.itemName))
			return false;
		if (material == null) {
			if (other.material != null)
				return false;
		} else if (!material.equals(other.material))
			return false;
		if (quantity != other.quantity)
			return false;
		if (size == null) {
			if (other.size != null)
				return false;
		} else if (!size.equals(other.size))
			return false;
		if (unitPrice != other.unitPrice)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Apparel [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", size="
				+ size + ", material=" + material + ", quantity=" + quantity + "]";
	}

	@Override
	public int compareTo(Apparel a) {
		// TODO Auto-generated method stub
		if(this.quantity > a.quantity)
			return 1;
		else if(this.quantity < a.quantity)
			return -1;
		return 0;
	}

	@Override
	public ArrayList<Apparel> getSales() throws NoSalesException {
		// TODO Auto-generated method stub
		ArrayList<Apparel> ala = new ArrayList<Apparel>();
		if(tsa.size()<0)
			throw new NoSalesException("No sales entries");
		else {
			for(int i=0;i<3;i++) {
				for(Apparel a:tsa) {
					ala.add(a);
				}
			  }
			}
			return ala;
	}
	
	
}
