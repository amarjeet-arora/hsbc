/**
 * 
 */
package com.exceptions;

/**
 * @author Jayesh
 *
 */
public class NoSalesException extends Exception {

	/**
	 * 
	 */
	public NoSalesException() {
		// TODO Auto-generated constructor stub
		super();
	}

	public NoSalesException(String message) {
		System.out.println(message);
	}
}
