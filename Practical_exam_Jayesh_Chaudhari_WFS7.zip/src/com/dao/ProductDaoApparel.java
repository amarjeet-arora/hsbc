package com.dao;
import java.util.Collection;
import com.entities.*;
import java.util.ArrayList;
import com.exceptions.NoSalesException;

public interface ProductDaoApparel  {
   public ArrayList<Apparel> getSales() throws NoSalesException;
}
