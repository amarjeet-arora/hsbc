package com.hsbc.service;

import java.util.Collection;

import com.hsbc.dao.FoodItemsDAOImpl;
import com.hsbc.dao.IFoodItemsDAO;

import com.hsbc.model.FoodItems;

public class FoodItemsService implements IFoodItemsService{

	
	IFoodItemsDAO dao=new FoodItemsDAOImpl();
	@Override
	public FoodItems createFoodItems(long itemCodeFood, String itemnameFood, boolean vegetarian, int quantityFood) {
		FoodItems foodcreate=new FoodItems(itemCodeFood, itemnameFood, vegetarian,quantityFood);
		FoodItems foodCreated=dao.saveFoodItems(foodcreate);
		return foodCreated;
	}

	@Override
	public Collection<FoodItems> fetchAll() {
		return this.dao.fetchAll();
	}
	


}
