package com.hsbc.service;

import java.util.Collection;

import com.hsbc.model.FoodItems;



public interface IFoodItemsService {
	
	public FoodItems createFoodItems(long itemCodeFood, String itemnameFood, boolean vegetarian, int quantityFood);
		
	public Collection<FoodItems> fetchAll();
	
}
