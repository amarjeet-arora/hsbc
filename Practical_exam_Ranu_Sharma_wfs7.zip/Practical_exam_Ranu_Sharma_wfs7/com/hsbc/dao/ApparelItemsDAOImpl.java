package com.hsbc.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.hsbc.model.Apparel;
import com.hsbc.model.FoodItems;

public class ApparelItemsDAOImpl implements IApparelItemsDAO{
	private static List<Apparel> applist=new ArrayList<>();

	@Override
	public Apparel saveApparel(Apparel ems) {
		applist.add(ems);
		return ems;
	}
	

	@Override
	public int updateApparel(long itemCodeApparelItems, int q) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public FoodItems fetchByItemCodeApparel(long itemCodeApparelItems) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Collection<Apparel> fetchAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
	
}