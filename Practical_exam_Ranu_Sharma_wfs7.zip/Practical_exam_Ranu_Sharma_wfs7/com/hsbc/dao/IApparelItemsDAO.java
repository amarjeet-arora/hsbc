package com.hsbc.dao;

import java.util.Collection;
import com.hsbc.model.Apparel;
import com.hsbc.model.FoodItems;

public interface IApparelItemsDAO {
	
	public Apparel saveApparel(Apparel ems);
	
	public int updateApparel(long itemCodeApparelItems,int q);
	
	public FoodItems fetchByItemCodeApparel(long itemCodeApparelItems);
	
	public Collection<Apparel> fetchAll();
}
