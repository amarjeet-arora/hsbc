/*Author:Ranu Sharma
 *This program will implement all the database function to perform operations on the datastructure 
 * */
package com.hsbc.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


import com.hsbc.model.FoodItems;

public class FoodItemsDAOImpl implements IFoodItemsDAO{
		
	private static List<FoodItems> foodlist=new ArrayList<>();

	@Override
	public FoodItems saveFoodItems(FoodItems foodItems) {
		//this function will save the new item.
		foodlist.add(foodItems);
		return foodItems;
	}

	@Override
	public int updateFoodItems(long itemCodeFoodItems, int q) {
		//This function will update the quantity of the item
		int t;
		for(FoodItems sa:foodlist){
			if(sa.getItemCodeFood()==itemCodeFoodItems){
				t=sa.getQuantityFood()+q;
				return t;
			}
			
		}
		return 0;
		
	}

	@Override
	public FoodItems fetchByItemCode(long itemCodeFoodItems) {
		//This function will return all the items matched with the item code
		for(FoodItems sa:foodlist){
			if(sa.getItemCodeFood()==itemCodeFoodItems){
				return sa;
			}
		
		}
		return null;
	}

	@Override
	public Collection<FoodItems> fetchAll() {
		//the is return all the fooditems
		return foodlist;
	}

}
