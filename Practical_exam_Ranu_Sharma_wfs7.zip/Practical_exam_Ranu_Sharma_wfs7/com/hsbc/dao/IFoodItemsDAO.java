package com.hsbc.dao;

import java.util.Collection;

import com.hsbc.model.FoodItems;


public interface IFoodItemsDAO {
	
	public FoodItems saveFoodItems(FoodItems ems);

	
	public int updateFoodItems(long itemCodeFoodItems,int q);
	
	public FoodItems fetchByItemCode(long itemCodeFoodItems);
	
	public Collection<FoodItems> fetchAll();
}
