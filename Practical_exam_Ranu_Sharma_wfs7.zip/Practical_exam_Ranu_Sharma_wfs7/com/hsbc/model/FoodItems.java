package com.hsbc.model;


public class FoodItems implements Comparable{
	
	private long itemCodeFood;
	private String itemnameFood;
	private double unitPriceFood;
	private String dateOfManufactureFood;
	private String dateOfExpiryFood;
	private static long counter=100;
	private boolean vegetarian;
	private int quantityFood;
	public FoodItems(long itemCodeFood, String itemnameFood, double unitPriceFood, String dateOfManufactureFood,
			String dateOfExpiryFood, boolean vegetarian, int quantityFood) {
		super();
		this.itemCodeFood = ++counter;
		this.itemnameFood = itemnameFood;
		this.unitPriceFood = unitPriceFood;
		this.dateOfManufactureFood = dateOfManufactureFood;
		this.dateOfExpiryFood = dateOfExpiryFood;
		this.vegetarian = vegetarian;
		this.quantityFood = quantityFood;
	}
	public FoodItems(long itemCodeFood, String itemnameFood, boolean vegetarian, int quantityFood) {
		super();
		this.itemCodeFood = itemCodeFood;
		this.itemnameFood = itemnameFood;
		this.vegetarian = vegetarian;
		this.quantityFood = quantityFood;
	}
	public String getItemnameFood() {
		return itemnameFood;
	}
	public void setItemnameFood(String itemnameFood) {
		this.itemnameFood = itemnameFood;
	}
	public double getUnitPriceFood() {
		return unitPriceFood;
	}
	public void setUnitPriceFood(double unitPriceFood) {
		this.unitPriceFood = unitPriceFood;
	}
	public String getDateOfManufactureFood() {
		return dateOfManufactureFood;
	}
	public void setDateOfManufactureFood(String dateOfManufactureFood) {
		this.dateOfManufactureFood = dateOfManufactureFood;
	}
	public String getDateOfExpiryFood() {
		return dateOfExpiryFood;
	}
	public void setDateOfExpiryFood(String dateOfExpiryFood) {
		this.dateOfExpiryFood = dateOfExpiryFood;
	}
	public static long getCounter() {
		return counter;
	}
	public static void setCounter(long counter) {
		FoodItems.counter = counter;
	}
	public boolean isVegetarian() {
		return vegetarian;
	}
	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}
	public int getQuantityFood() {
		return quantityFood;
	}
	public void setQuantityFood(int quantityFood) {
		this.quantityFood = quantityFood;
	}
	public long getItemCodeFood() {
		return itemCodeFood;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (itemCodeFood ^ (itemCodeFood >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FoodItems other = (FoodItems) obj;
		if (itemCodeFood != other.itemCodeFood)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "FoodItems [itemCodeFood=" + itemCodeFood + ", itemnameFood=" + itemnameFood + ", unitPriceFood="
				+ unitPriceFood + ", dateOfManufactureFood=" + dateOfManufactureFood + ", dateOfExpiryFood="
				+ dateOfExpiryFood + ", vegetarian=" + vegetarian + ", quantityFood=" + quantityFood + "]";
	}
	
	 public int compareTo(FoodItems comparestu) {
	  
		 return comparestu.getQuantityFood()-this.getQuantityFood();

	    }
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
