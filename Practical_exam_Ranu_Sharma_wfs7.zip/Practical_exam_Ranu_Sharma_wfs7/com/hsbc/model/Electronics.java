/*Author:Ranu Sharma
 * */
package com.hsbc.model;

public class Electronics {
	private long itemCodeElectronics;
	private String itemnameElectronics;
	private double unitPriceElectronics;
	private int warranty;		
	private int quantityElectronics;
	public long getItemCodeElectronics() {
		return itemCodeElectronics;
	}
	public void setItemCodeElectronics(long itemCodeElectronics) {
		this.itemCodeElectronics = itemCodeElectronics;
	}
	public String getItemnameElectronics() {
		return itemnameElectronics;
	}
	public void setItemnameElectronics(String itemnameElectronics) {
		this.itemnameElectronics = itemnameElectronics;
	}
	public double getUnitPriceElectronics() {
		return unitPriceElectronics;
	}
	public void setUnitPriceElectronics(double unitPriceElectronics) {
		this.unitPriceElectronics = unitPriceElectronics;
	}
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	public int getQuantityElectronics() {
		return quantityElectronics;
	}
	public void setQuantityElectronics(int quantityElectronics) {
		this.quantityElectronics = quantityElectronics;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (itemCodeElectronics ^ (itemCodeElectronics >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Electronics other = (Electronics) obj;
		if (itemCodeElectronics != other.itemCodeElectronics)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Electronics [itemCodeElectronics=" + itemCodeElectronics + ", itemnameElectronics="
				+ itemnameElectronics + ", unitPriceElectronics=" + unitPriceElectronics + ", warranty=" + warranty
				+ ", quantityElectronics=" + quantityElectronics + "]";
	}
	 public int compareTo(Electronics comparestu) {
		  
		 return comparestu.getQuantityElectronics()-this.getQuantityElectronics();

	    }
	
}
