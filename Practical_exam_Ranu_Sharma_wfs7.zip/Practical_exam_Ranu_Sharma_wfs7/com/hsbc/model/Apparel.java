/*Author:Ranu Sharma
 * */
package com.hsbc.model;

public class Apparel {
	private long itemCodeApparel;
	private String itemnameApparel;
	private double unitPriceApparel;
	private int sizeApparel;
	private String material;	
	private int quantityApparel;
	public long getItemCodeApparel() {
		return itemCodeApparel;
	}
	public void setItemCodeApparel(long itemCodeApparel) {
		this.itemCodeApparel = itemCodeApparel;
	}
	public String getItemnameApparel() {
		return itemnameApparel;
	}
	public void setItemnameApparel(String itemnameApparel) {
		this.itemnameApparel = itemnameApparel;
	}
	public double getUnitPriceApparel() {
		return unitPriceApparel;
	}
	public void setUnitPriceApparel(double unitPriceApparel) {
		this.unitPriceApparel = unitPriceApparel;
	}
	public int getSizeApparel() {
		return sizeApparel;
	}
	public void setSizeApparel(int sizeApparel) {
		this.sizeApparel = sizeApparel;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public int getQuantityApparel() {
		return quantityApparel;
	}
	public void setQuantityApparel(int quantityApparel) {
		this.quantityApparel = quantityApparel;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (itemCodeApparel ^ (itemCodeApparel >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparel other = (Apparel) obj;
		if (itemCodeApparel != other.itemCodeApparel)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Apparel [itemCodeApparel=" + itemCodeApparel + ", itemnameApparel=" + itemnameApparel
				+ ", unitPriceApparel=" + unitPriceApparel + ", sizeApparel=" + sizeApparel + ", material=" + material
				+ ", quantityApparel=" + quantityApparel + "]";
	}
	 public int compareTo(Apparel comparestu) {		  
		 return comparestu.getQuantityApparel()-this.getQuantityApparel();

	    }
}
