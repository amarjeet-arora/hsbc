package com.hsbc.exception;
//this is a userdefined exception
public class ItemNotFoundException extends Exception {
	public ItemNotFoundException() {
		super();
	}
	public ItemNotFoundException(String message){
		super(message);
	}

}
