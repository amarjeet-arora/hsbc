/**
 * 
 */
package com.everyday.salesreport.models;

/**
 * @author Rohitkaran
 * 
 * This file declares the various members of Apparel.
 *
 */
public class Apparel {
	
	//Various members of Apparel class as per requirement.
	
	private int itemCode;
	private String itemName;
	private double unitPrice;
	private String size;
	private String material;
	private int quantity;
	
	//Non-parameterized constructor
	public Apparel() {
		super();
	}

	//Parameterized constructor
	public Apparel(int itemCode, String itemName, double unitPrice, String size, String material, int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.size = size;
		this.material = material;
		this.quantity = quantity;
	}

	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Apparel [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", size="
				+ size + ", material=" + material + ", quantity=" + quantity + "]";
	}
	

}
