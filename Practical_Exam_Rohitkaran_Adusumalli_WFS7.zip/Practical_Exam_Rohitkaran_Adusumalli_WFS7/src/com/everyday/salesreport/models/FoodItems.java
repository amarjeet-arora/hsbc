/**
 * 
 */
package com.everyday.salesreport.models;

/**
 * @author Rohitkaran
 * 
 * This file declares the various members of Food Items
 *
 */
public class FoodItems {
	
	//Various members of FoodItem class as per requirement.
	
	private int itemCode;
	private String itemName;
	private double unitPrice;
	private String dateOfManufacture;
	private String dateOfExpiry;
	private boolean isVegeterian;
	private int quantity;
	
	//Non-parameterized constructor
	public FoodItems() {
		super();
	}
	
	//Parameterized constructor
	public FoodItems(int itemCode, String itemName, double unitPrice, String dateOfManufacture, String dateOfExpiry,
			boolean isVegeterian, int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpiry = dateOfExpiry;
		this.isVegeterian = isVegeterian;
		this.quantity = quantity;
	}

	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	public String getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(String dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

	public boolean isVegeterian() {
		return isVegeterian;
	}

	public void setVegeterian(boolean isVegeterian) {
		this.isVegeterian = isVegeterian;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "FoodItems [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", isVegeterian="
				+ isVegeterian + ", quantity=" + quantity + "]";
	}
	
	
	

}
