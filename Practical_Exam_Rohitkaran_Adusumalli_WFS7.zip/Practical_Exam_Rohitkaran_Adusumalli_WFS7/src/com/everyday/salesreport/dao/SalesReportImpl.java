/**
 * 
 */
package com.everyday.salesreport.dao;

import java.util.List;

import com.everyday.salesreport.models.Apparel;
import com.everyday.salesreport.models.Electronics;
import com.everyday.salesreport.models.FoodItems;

/**
 * @author Rohitkaran
 *
 */
public class SalesReportImpl implements SalesReport{

	@Override
	public List<FoodItems> foodItemsReport(List<FoodItems> foodItemList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Apparel> apparelReport(List<Apparel> apparelList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Electronics> electronicsReport(List<Electronics> electronicsList) {
		// TODO Auto-generated method stub
		return null;
	}


}
