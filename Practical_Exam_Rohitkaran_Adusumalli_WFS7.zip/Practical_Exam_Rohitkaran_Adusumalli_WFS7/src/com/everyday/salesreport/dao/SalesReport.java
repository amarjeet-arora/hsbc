/**
 * 
 */
package com.everyday.salesreport.dao;

import java.util.List;

import com.everyday.salesreport.models.*;

/**
 * @author Rohitkaran
 * 
 * This file shows the blueprint of SalesReport.
 *
 */
public interface SalesReport {
	
	List<FoodItems> foodItemsReport(List<FoodItems> foodItemList);
	List<Apparel> apparelReport(List<Apparel> apparelList);
	List<Electronics> electronicsReport(List<Electronics> electronicsList);

}
