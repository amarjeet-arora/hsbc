/**
 * 
 */
package com.everyday.salesreport.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.everyday.salesreport.bl.SalesReportblImpl;
import com.everyday.salesreport.exceptions.CategoryNotFoundException;
import com.everyday.salesreport.models.Apparel;
import com.everyday.salesreport.models.Electronics;
import com.everyday.salesreport.models.FoodItems;

/**
 * @author Rohitkaran
 *
 */
public class SalesReportApp {
	
	public static void main(String[] args) throws CategoryNotFoundException {
		
		List<FoodItems> foodItemsList = new ArrayList<FoodItems>();
		List<Apparel> apparelList = new ArrayList<Apparel>();
		List<Electronics> electronicsList = new ArrayList<Electronics>();
		
		foodItemsList.add(new FoodItems(1001,"Bread",45,"2020-09-10","2020-09-12",true,10));
		foodItemsList.add(new FoodItems(1002,"Jam",100,"2020-03-10","2020-09-10",true,5));
		foodItemsList.add(new FoodItems(1003,"Cadbury Chocolate",90,"2020-03-10","2020-10-10",true,20));
		foodItemsList.add(new FoodItems(1004,"Lays",10,"2020-09-10","2020-09-12",true,25));
		
		apparelList.add(new Apparel(1101,"Levi's Shirt",1200,"M","Cotton",2));
		apparelList.add(new Apparel(1102,"Pepe Jeans",2200,"M","Cotton",1));
		apparelList.add(new Apparel(1103,"Levi's T-Shirt",1400,"L","Cotton",3));
		apparelList.add(new Apparel(1104,"Raymonds Shirt",1700,"XL","Cotton",2));
		
		electronicsList.add(new Electronics(1201,"Laptop",120000,12,1));
		electronicsList.add(new Electronics(1202,"Mobile",20000,24,3));
		electronicsList.add(new Electronics(1203,"Router",1500,36,2));
		electronicsList.add(new Electronics(1204,"Power Bank",2300,12,6));
		
		int category;
		
		System.out.println("Available Categories : -"
				+ "1. Food Items"
				+ "2. Apparel"
				+ "3. Electronics");
		System.out.println("Enter the category for which you want to generate the report :");
		Scanner sc = new Scanner(System.in);
		category = sc.nextInt();
		
		switch(category) {
			case 1:
				//Accessing the Business layer layer to get the report.
				List<FoodItems> fil = new SalesReportblImpl().foodItemsReport(foodItemsList);
				System.out.println("The sales report for food items is as follows :");
				System.out.println(fil);
				break;
			case 2:
				//Accessing the Business layer layer to get the report.
				List<Apparel> al = new SalesReportblImpl().apparelReport(apparelList);
				System.out.println("The sales report for apparel is as follows :");
				System.out.println(al);
				break;
			case 3:
				//Accessing the Business layer layer to get the report.
				List<Electronics> el = new SalesReportblImpl().electronicsReport(electronicsList);
				System.out.println("The sales report for apparel is as follows :");
				System.out.println(el);
				break;
			default:
				throw new CategoryNotFoundException("Error : No such category is to be found.");
		}
		
	}

}
