/**
 * 
 */
package com.everyday.salesreport.bl;

import java.util.List;

import com.everyday.salesreport.models.Apparel;
import com.everyday.salesreport.models.Electronics;
import com.everyday.salesreport.models.FoodItems;

/**
 * @author Rohitkaran
 *
 */
public class SalesReportblImpl implements SalesReportbl{

	@Override
	public List<FoodItems> foodItemsReport(List<FoodItems> foodItemList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Apparel> apparelReport(List<Apparel> apparelList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Electronics> electronicsReport(List<Electronics> electronicsList) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
