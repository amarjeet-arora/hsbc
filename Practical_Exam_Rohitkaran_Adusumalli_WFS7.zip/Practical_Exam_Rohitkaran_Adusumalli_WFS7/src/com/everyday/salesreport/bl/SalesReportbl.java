/**
 * 
 */
package com.everyday.salesreport.bl;

import java.util.List;

import com.everyday.salesreport.models.Apparel;
import com.everyday.salesreport.models.Electronics;
import com.everyday.salesreport.models.FoodItems;

/**
 * @author Rohitkaran
 * 
 * This file gives the blueprint for implementation.
 *
 */
public interface SalesReportbl {
	
	List<FoodItems> foodItemsReport(List<FoodItems> foodItemList);
	List<Apparel> apparelReport(List<Apparel> apparelList);
	List<Electronics> electronicsReport(List<Electronics> electronicsList);

}
