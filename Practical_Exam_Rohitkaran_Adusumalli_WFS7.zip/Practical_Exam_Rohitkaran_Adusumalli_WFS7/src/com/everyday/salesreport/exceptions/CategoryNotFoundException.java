/**
 * 
 */
package com.everyday.salesreport.exceptions;

/**
 * @author Rohitkaran
 * 
 * This file is definition of category not found exception.
 *
 */
public class CategoryNotFoundException extends Exception{
	
	public CategoryNotFoundException(String message)
	{
		super(message);
	}
	
}
