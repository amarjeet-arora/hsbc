/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: IElectronicsDao interafce provides the structure of electronics objects 
 */

package com.practical.dataaccesslayer;

import java.util.Collection;

import com.practical.entity.Electronics;
import com.practical.exceptions.ItemAlreadyExists;

public interface IElectronicsDao {
	
	Electronics addItem(Electronics e) throws ItemAlreadyExists;
	Collection<Electronics> showItems();

}
