/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: IApparelDao interafce provides the structure of apparel objects 
 */

package com.practical.dataaccesslayer

import java.util.Collection;


import com.practical.entity.Apparel;
import com.practical.exceptions.ItemAlreadyExists;

public interface IApparelDao {
	
	Apparel addItem(Apparel a) throws ItemAlreadyExists;
	Collection<Apparel> showItems();

}
