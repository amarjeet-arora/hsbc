/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: IFoodItemsDao interafce provides the structure of FoodItems objects 
 */



package com.practical.dataaccesslayer;

import java.util.Collection;

import com.practical.entity.FoodItems;
import com.practical.exceptions.ItemAlreadyExists;

public interface IFoodItemsDao {
	
	FoodItems addItems(FoodItems f) throws ItemAlreadyExists;  
	Collection<FoodItems> showItems();
	
	

}
