/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: ApparelDaoImpl class is implemtation class of ApparelDao interace and is providing functionalities to the methods present in the interface
 */



package com.practical.businesslogiclayer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import com.practical.businesslogiclayer.QuantityComparatorApparel;
import com.practical.dataaccesslayer.IApparelDao;
import com.practical.entity.Apparel;
import com.practical.exceptions.ItemAlreadyExists;

public class ApparelDaoImpl implements IApparelDao{

	ArrayList<Apparel> al=new ArrayList<Apparel>();
	@Override
	public Apparel addItem(Apparel a) throws ItemAlreadyExists //adds the apparel item passed as paratmeter to the item list and if already present then throws an exception
	{
	 
		if(al.contains(a))
			throw new ItemAlreadyExists("Item already present...");
		else
			al.add(a);
		
		return a;
		
	}

	@Override
	public Collection<Apparel> showItems()  //returns the items in the list based on the decreasing order of quantity
	{
		// TODO Auto-generated method stub
		
		Collections.sort(al,QuantityComparatorApparel);
		Collections.reverseOrder(QuantityComparatorApparel);
		return al.values();
		
		
		
	}
	
	

}
