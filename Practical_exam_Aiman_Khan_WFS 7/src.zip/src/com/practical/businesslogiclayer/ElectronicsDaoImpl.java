/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: ElectronicsDaoImpl class is implemtation class of ElectronicsDao interface and is providing functionalities to the methods present in the interface
 */


package com.practical.businesslogiclayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import com.practical.dataaccesslayer.IElectronicsDao;
import com.practical.entity.Apparel;
import com.practical.entity.Electronics;
import com.practical.exceptions.ItemAlreadyExists;

public class ElectronicsDaoImpl implements IElectronicsDao {

	ArrayList<Electronics> al=new ArrayList<Electronics>();
	@Override
	public Electronics addItem(Electronics e) throws ItemAlreadyExists //adds the electronics item passed as parameter to the item list and if already present then throws an exception
	{
		
		if(al.contains(e))
			throw new ItemAlreadyExists("Item already present...");
		else
			al.add(e);
		return e;
	}

	@Override
	public Collection<Electronics> showItems() //returns the items in the list based on the decreasing order of quantity
	{
		// TODO Auto-generated method stub
		
		
		Collections.sort(al,QuantityComparatorElectronics);
		Collections.reverseOrder(QuantityComparatorElectronics);
		return al.values();
	}

}
