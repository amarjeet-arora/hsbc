/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: FoodItemsDaoImpl class is implemtation class of ApparelDao interace and is providing functionalities to the methods present in the interface
 */

package com.practical.businesslogiclayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import com.practical.dataaccesslayer.IFoodItemsDao;
import com.practical.entity.Electronics;
import com.practical.entity.FoodItems;
import com.practical.exceptions.ItemAlreadyExists;

public class FoodItemsDaoImpl implements IFoodItemsDao {

	
	ArrayList<FoodItems> al=new ArrayList<FoodItems>();
	
	@Override
	public FoodItems addItems(FoodItems f) throws ItemAlreadyExists { //adds the food item item passed as parameter to the item list and if already present then throws an exception
		
		if(al.contains(f))
			throw new ItemAlreadyExists("Item already present...");
		else
			al.add(f);
		return f;
	}

	@Override
	public Collection<FoodItems> showItems() {        //returns the items in the list based on the decreasing order of quantity
		
		Collections.sort(al,QuantityComparatorFoodItems);
		Collections.reverseOrder(QuantityComparatorItems);
		return al.values();
	}

}
