/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose:QuantityComaparatorElectronics  class is a comparator class for the Electronics class where the objects of Electronics class are compared based on the quantity
 */


package com.practical.businesslogiclayer;

import java.util.Comparator;

import com.practical.entity.Apparel;
import com.practical.entity.Electronics;
import com.practical.entity.FoodItems;

public class QuantityComaparatorElectronics implements Comparator<Electronics> {

	@Override
	public int compare(Electronics o1, Electronics o2) {
		// TODO Auto-generated method stub
		
		return o1.getQuantity()-o2.getQuantity();
	}

	
	


}
