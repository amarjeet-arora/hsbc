/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose:QuantityComaparatorApparel  class is a comparator class for the Apparel class where the objects of Apparel class are compared based on the quantity
 */

package com.practical.businesslogiclayer;

import java.util.Comparator;

import com.practical.entity.Apparel;
import com.practical.entity.FoodItems;

public class QuantityComparatorApparel implements Comparator<Apparel> {

	@Override
	public int compare(Apparel o1, Apparel o2) {
		// TODO Auto-generated method stub
		return o1.getQuantity()-o2.getQuantity();
	}

}
