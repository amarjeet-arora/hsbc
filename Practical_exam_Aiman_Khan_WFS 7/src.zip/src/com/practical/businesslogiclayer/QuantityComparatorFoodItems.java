/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose:QuantityComaparatorFoodItems  class is a comparator class for the FoodItems class where the objects of FoodItems class are compared based on the quantity
 */


package com.practical.businesslogiclayer;

import java.util.Collection;
import java.util.Comparator;

import com.practical.dataaccesslayer.IFoodItemsDao;
import com.practical.entity.Electronics;
import com.practical.entity.FoodItems;
import com.practical.exceptions.ItemAlreadyExists;

public class QuantityComparatorFoodItems implements Comparator<FoodItems> {

	@Override
	public int compare(FoodItems o1, FoodItems o2) {
		// TODO Auto-generated method stub
	
		return o1.getQuantity()-o2.getQuantity();
	}
	



}
