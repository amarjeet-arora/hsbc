/*                                                                                                                                                                           
 ********************************************************* Author : Aiman Khan*********************************************                                                                                               
 * Purpose: ItemAlreadyExists is a customized exception class and is thrown when the item entered by the user will already be present in the item list 
 */     

package com.practical.exceptions;

public class ItemAlreadyExists extends Exception {

	public ItemAlreadyExists() {
		super();
		
	}

	public ItemAlreadyExists(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	
	}

	public ItemAlreadyExists(String message, Throwable cause) {
		super(message, cause);
	
	}

	public ItemAlreadyExists(String message) {
		super(message);
	
	}

	public ItemAlreadyExists(Throwable cause) {
		super(cause);
	
	}
	
	

}
