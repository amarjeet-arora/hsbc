/*                                                                                                                                                                           
 ********************************************************* Author : Aiman Khan*********************************************                                                                                               
 * Purpose: CategoryNotFound is a customized exception class and is thrown when the category entered by the user will not be present in the already defined category list 
 */                                                                                                                                                                          
                                                                                                                                                                             
                                                                                                                                                                             


package com.practical.exceptions;

public class CategoryNotFound extends Exception {

	public CategoryNotFound() {
		super();
	
	}

	public CategoryNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public CategoryNotFound(String message, Throwable cause) {
		super(message, cause);
		
	}

	public CategoryNotFound(String message) {
		super(message);
		
	}

	public CategoryNotFound(Throwable cause) {
		super(cause);
		
	}
	
	

}
