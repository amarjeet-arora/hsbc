/*
 ********************************************************* Author : Aiman Khan**************************************************************************
 * Purpose: Apparel class is describing the properties of apparels pesent in the comapny and contains constructors,methods for getting and setting the values of data variables.
 */

package com.practical.entity;

public class Apparel {
	
	int itemCode;
	String itemName;
	int unitPrice;
	int size;
	boolean isCotton;     //boolean variable isCotton, if true then the material is cotton otherwise it is wollen
	int quantity;
	
	
	public Apparel() {
		super();
	}


	public Apparel(int itemCode, String itemName, int unitPrice, int size, boolean isCotton, int quantity) { //parametrized constructor
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.size = size;
		this.isCotton = isCotton;
		this.quantity = quantity;
	}


	
	/**
	 * @return the itemCode
	 */
	public int getItemCode() {
		return itemCode;
	}


	/**
	 * @param itemCode the itemCode to set
	 */
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}


	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}


	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	/**
	 * @return the unitPrice
	 */
	public int getUnitPrice() {
		return unitPrice;
	}


	/**
	 * @param unitPrice the unitPrice to set
	 */
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}


	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}


	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}


	/**
	 * @return the isCotton
	 */
	public boolean isCotton() {
		return isCotton;
	}


	/**
	 * @param isCotton the isCotton to set
	 */
	public void setCotton(boolean isCotton) {
		this.isCotton = isCotton;
	}


	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}


	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (isCotton ? 1231 : 1237);
		result = prime * result + itemCode;
		result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
		result = prime * result + quantity;
		result = prime * result + size;
		result = prime * result + unitPrice;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparel other = (Apparel) obj;
		if (isCotton != other.isCotton)
			return false;
		if (itemCode != other.itemCode)
			return false;
		if (itemName == null) {
			if (other.itemName != null)
				return false;
		} else if (!itemName.equals(other.itemName))
			return false;
		if (quantity != other.quantity)
			return false;
		if (size != other.size)
			return false;
		if (unitPrice != other.unitPrice)
			return false;
		return true;
	}


	@Override
	public String toString() {
		
		String material = this.isCotton ? "cotton" : "wollen";
		return "Apparel [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice + ", size="
				+ size + ", isCotton=" + isCotton + ", material=" + material + "]";
	}
	
	
	
	
	
	

}
