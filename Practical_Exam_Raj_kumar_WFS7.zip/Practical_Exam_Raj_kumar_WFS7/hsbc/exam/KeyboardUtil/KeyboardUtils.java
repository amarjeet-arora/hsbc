
package hsbc.exam.KeyboardUtil;

import hsbc.exam.Entity.Apparel;
import hsbc.exam.Entity.Electronics;
import hsbc.exam.Entity.Food;
import java.util.Scanner;

public class KeyboardUtils {
    static Scanner input = new Scanner(System.in);
    public static Food getFoodData(){
        String dateOfManufacture,dateOfExpiry,itemName;
        boolean Vegetarian;
        int  itemCode, quantitySold;
        float price;
        input.nextLine();
        System.out.println("Enter food name: ");
        itemName = input.nextLine();
        System.out.println("Enter food dateOfManufacture: ");
        dateOfManufacture = input.nextLine();
        System.out.println("Enter food dateOfExpiry: ");
        dateOfExpiry = input.nextLine();
        System.out.println("Enter its Item Code: ");
        itemCode= input.nextInt();
        System.out.println("Enter its Quantity Sold: ");
        quantitySold= input.nextInt();
        System.out.println("Enter its price: ");
        price= input.nextFloat();
        input.nextLine();
        System.out.println("is it Vegetarian ? [y/n]");
        String temp = input.nextLine();
        if(temp.equals("y"))
            Vegetarian = true;
        else
            Vegetarian = false;
        return new Food( dateOfManufacture,  dateOfExpiry,  Vegetarian,  itemName,  itemCode,  quantitySold,  price);
        
    }
    public static Apparel getApparelData(){
        String size,material, itemName;
        int itemCode, quantitySold;
        float price;
        System.out.println("Enter food name: ");
        itemName = input.nextLine();
        System.out.println("Enter food size: ");
        size = input.nextLine();
        System.out.println("Enter food material: ");
        material = input.nextLine();
        System.out.println("Enter its Item Code: ");
        itemCode= input.nextInt();
        System.out.println("Enter its Quantity Sold: ");
        quantitySold= input.nextInt();
        System.out.println("Enter its price: ");
        price= input.nextFloat();
        input.nextLine();
        return new Apparel( size,  material,  itemName,  itemCode,  quantitySold,  price);
        
    }
    public static Electronics getElectronicsData(){
        int warranty;
        String itemName;
        int itemCode ,quantitySold;
        float price;
        System.out.println("Enter food name: ");
        itemName = input.nextLine();
        System.out.println("Enter its Item Code: ");
        itemCode= input.nextInt();
        System.out.println("Enter Warranty of this electronic item: ");
        warranty= input.nextInt();
        System.out.println("Enter its Quantity Sold: ");
        quantitySold= input.nextInt();
        System.out.println("Enter its price: ");
        price= input.nextFloat();
        input.nextLine();
        return new Electronics(  warranty,  itemName,  itemCode,  quantitySold,  price);
        
    }
}
