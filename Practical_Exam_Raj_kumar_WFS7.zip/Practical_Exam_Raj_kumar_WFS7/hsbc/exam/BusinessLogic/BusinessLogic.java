/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam.BusinessLogic;

import hsbc.exam.DataAccess.DataAccess;
import hsbc.exam.DataAccess.DataAccessImpl;
import hsbc.exam.Entity.Apparel;
import hsbc.exam.Entity.Electronics;
import hsbc.exam.Entity.Food;
import hsbc.exam.Exception.CustomException;
import hsbc.exam.Exception.ProductAlreadyExistsException;
import hsbc.exam.Exception.ProductNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author surya
 */
public class BusinessLogic {
//    public static void main(String arr[]){
//        DataAccessImpl.add();
//        System.out.println("added");
//        try {
//            List l = showTopThreeProducts("food");
//            ArrayList<Food> list = (ArrayList<Food>)l;
//            for(Food f:list){
//                System.out.println(f);
//            }
//        } catch (CustomException ex) {
//            Logger.getLogger(BusinessLogic.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    public List showTopThreeProducts(String types) throws CustomException{
        DataAccess doa  = new DataAccessImpl();
        types= types.toLowerCase();
         if(types.equals("food")){
            ArrayList<Food> list = (ArrayList<Food>)doa.listProducts("food");
            Collections.sort(list);
            return list.subList(0, 2);
        }
            
        else if(types.equals("apparel")){
            ArrayList<Food> list = (ArrayList<Food>)doa.listProducts("apparel");
            Collections.sort(list);
            return list.subList(0, 2);
        }
        else{
           ArrayList<Food> list = (ArrayList<Food>)doa.listProducts("electronics");
            Collections.sort(list);
            return list.subList(0, 2);
        }
    }
    public void AddSoledProduct(Object product) throws ProductAlreadyExistsException{
        DataAccess doa = new DataAccessImpl();
        Food food;
        Electronics ele;
        Apparel app;
        if(product instanceof Food){
            food = (Food)product;
            doa.addSoledProduct(product);
        }
            
        else if(product instanceof Apparel){
            app = (Apparel)product;
            doa.addSoledProduct(product);
        }
        else{
            ele = (Electronics)product;
            doa.addSoledProduct(product);
        }
    }
    
    public void RemoveSoledProduct(Object product) throws ProductNotFoundException{
        DataAccess doa = new DataAccessImpl();
        Food food;
        Electronics ele;
        Apparel app;
        if(product instanceof Food){
            food = (Food)product;
            doa.removeSoledProduct(food);
        }
            
        else if(product instanceof Apparel){
            app = (Apparel)product;
            doa.removeSoledProduct(app);
        }
        else{
            ele = (Electronics)product;
            doa.removeSoledProduct(ele);
        }
    }
}
