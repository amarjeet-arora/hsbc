
package hsbc.exam.Entity;

public class Food implements Comparable<Food> {
    private String dateOfManufacture;
    private String dateOfExpiry;
    private boolean Vegetarian;
    private String itemName;
    private int itemCode;
    private int quantitySold;
    private float price;

    public Food(String dateOfManufacture, String dateOfExpiry, boolean Vegetarian, String itemName, int itemCode, int quantitySold, float price) {
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.quantitySold = quantitySold;
        this.price = price;
        this.dateOfManufacture = dateOfManufacture;
        this.dateOfExpiry = dateOfExpiry;
        this.Vegetarian = Vegetarian;
    }

    public Food() {
        super();
    }

    public String getDateOfManufacture() {
        return dateOfManufacture;
    }

    public void setDateOfManufacture(String dateOfManufacture) {
        this.dateOfManufacture = dateOfManufacture;
    }

    public String getDateOfExpiry() {
        return dateOfExpiry;
    }

    public void setDateOfExpiry(String dateOfExpiry) {
        this.dateOfExpiry = dateOfExpiry;
    }

    public boolean isVegetarian() {
        return Vegetarian;
    }

    public void setVegetarian(boolean Vegetarian) {
        this.Vegetarian = Vegetarian;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getItemCode() {
        return itemCode;
    }

    public void setItemCode(int itemCode) {
        this.itemCode = itemCode;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }


    @Override
    public int compareTo(Food o) {
        return o.quantitySold - this.quantitySold;
    }

    @Override
    public String toString() {
        return "Food{" + "dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", Vegetarian=" + Vegetarian + ", itemName=" + itemName + ", itemCode=" + itemCode + ", quantitySold=" + quantitySold + ", price=" + price + '}';
    }
    
    
    
}
