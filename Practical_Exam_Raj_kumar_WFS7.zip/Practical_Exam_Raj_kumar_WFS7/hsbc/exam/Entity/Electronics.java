/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam.Entity;

/**
 *
 * @author surya
 */
public class Electronics implements Comparable<Electronics>{
    private int warranty;
    protected String itemName;
    protected int itemCode;
    protected int quantitySold;
    protected float price;
    public Electronics(int warranty, String itemName, int itemCode, int quantitySold, float price) {
        this.itemName = itemName;
        this.itemCode = itemCode;
        this.quantitySold = quantitySold;
        this.price = price;
        this.warranty = warranty;
    }

    public Electronics() {
        super();
    }

    public int getWarranty() {
        return warranty;
    }

    public void setWarranty(int warranty) {
        this.warranty = warranty;
    }

     public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    
    public int getItemCode() {
        return itemCode;
    }

    public void setItemCode(int itemCode) {
        this.itemCode = itemCode;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public int compareTo(Electronics o) {
        return o.quantitySold - this.quantitySold;
    }
    
}
