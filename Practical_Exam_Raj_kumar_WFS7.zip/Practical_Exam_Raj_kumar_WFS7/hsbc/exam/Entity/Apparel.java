/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam.Entity;

/**
 *
 * @author surya
 */
public class Apparel implements Comparable<Apparel>{
    private String size;
    private String material;
    protected String itemName;
    protected int itemCode;
    protected int quantitySold;
    protected float price;
    public Apparel(String size, String material, String itemName, int itemCode, int quantitySold, float price) {

        this.itemName = itemName;
        this.itemCode = itemCode;
        this.quantitySold = quantitySold;
        this.price = price;
        this.size = size;
        this.material = material;
    }

    public Apparel() {
        super();
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getItemCode() {
        return itemCode;
    }

    public void setItemCode(int itemCode) {
        this.itemCode = itemCode;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public int compareTo(Apparel o) {
        return o.quantitySold - this.quantitySold;
    }
    
}
