/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam.DataAccess;

import hsbc.exam.Exception.CustomException;
import hsbc.exam.Exception.ProductAlreadyExistsException;
import hsbc.exam.Exception.ProductNotFoundException;
import java.util.List;

/**
 *
 * @author surya
 */
public interface DataAccess {
    
    void addSoledProduct(Object a) throws ProductAlreadyExistsException;
    void removeSoledProduct(Object a) throws ProductNotFoundException;
    List listProducts(String type) throws CustomException;
    
}
