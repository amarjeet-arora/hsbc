
package hsbc.exam.DataAccess;

import hsbc.exam.Entity.Apparel;
import hsbc.exam.Entity.Electronics;
import hsbc.exam.Entity.Food;
import hsbc.exam.Exception.CustomException;
import hsbc.exam.Exception.ProductAlreadyExistsException;
import hsbc.exam.Exception.ProductNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author surya
 */
public class DataAccessImpl implements DataAccess{
    
    static private ArrayList<Apparel> apparelList;
    static private ArrayList<Food> foodList;
    static private ArrayList<Electronics> eleList;
    
    public static void add(){
        foodList = new ArrayList();
        for(int i=0;i<6;i++){
            foodList.add(new Food(Integer.toString(i),Integer.toString(i),false,i+"",i,i,i));
        }
    }
    @Override
    public void addSoledProduct(Object a) throws ProductAlreadyExistsException {

        Food food;
        Electronics ele;
        Apparel app;
        if(a instanceof Food){
            food = (Food)a;
            foodList.add(food);
        }
            
        else if(a instanceof Apparel){
            app = (Apparel)a;
            apparelList.add(app);
        }
        else{
            ele = (Electronics)a;
            eleList.add(ele);
        }
        
    }

    @Override
    public void removeSoledProduct(Object a) throws ProductNotFoundException {
       Food food;
        Electronics ele;
        Apparel app;
        if(a instanceof Food){
            food = (Food)a;
            int i=0;
            for(i=0;i<foodList.size();i++){
                if(food.getItemCode()==foodList.get(i).getItemCode()){
                    foodList.remove(i);
                }
            }
            if(i==foodList.size())
                throw new ProductNotFoundException("Product Not Present in the list");
        }
            
        else if(a instanceof Apparel){
           
            app = (Apparel)a;
            int i=0;
            for(i=0;i<apparelList.size();i++){
                if(app.getItemCode()==apparelList.get(i).getItemCode()){
                    apparelList.remove(i);
                }
            }
            if(i==apparelList.size())
                throw new ProductNotFoundException("Product Not Present in the list");
            
        }
        else{
            ele = (Electronics)a;
            int i=0;
            for(i=0;i<eleList.size();i++){
                if(ele.getItemCode()==eleList.get(i).getItemCode()){
                    eleList.remove(i);
                }
            }
            if(i==eleList.size())
                throw new ProductNotFoundException("Product Not Present in the list");
        }
    }
    
    @Override
    public List listProducts(String types) throws CustomException {
        types= types.toLowerCase();
        
         if(types.equals("food")){
            return (List)foodList;
        }
        else if(types.equals("apparel")){
            return (List)apparelList;
        }
        else{
            return (List)eleList;
        }
    }
    
}
