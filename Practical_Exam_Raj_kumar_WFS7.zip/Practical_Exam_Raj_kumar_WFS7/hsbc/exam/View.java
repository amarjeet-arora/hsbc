/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam;

import hsbc.exam.BusinessLogic.BusinessLogic;
import hsbc.exam.Exception.CustomException;
import hsbc.exam.Exception.ProductAlreadyExistsException;
import hsbc.exam.KeyboardUtil.KeyboardUtils;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author surya
 */
public class View {

    /**
     * @param args the command line arguments
     */
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        // TODO code application logic here
        String y = null;
        do{
        System.out.println("Enter 1 to Add Food data\nEnter 2 to Add Apparel data\nEnter 3 to Add Electronics data");
        int val = input.nextInt();
        switch(val){
            case 1:
                {
                    try {
                        new BusinessLogic().AddSoledProduct(KeyboardUtils.getFoodData());
                    } catch (ProductAlreadyExistsException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
                break;
            case 2:
                {
                    try {
                        new BusinessLogic().AddSoledProduct(KeyboardUtils.getFoodData());
                    } catch (ProductAlreadyExistsException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
                break;
            case 3:
                {
                    try {
                        new BusinessLogic().AddSoledProduct(KeyboardUtils.getFoodData());
                    } catch (ProductAlreadyExistsException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
                break;
        }
        System.out.println("Want to Add More Data? [y/n]");
         y = input.nextLine();
        }while(y.toLowerCase().equals('y'));
        System.out.println("Top three Products of Each entity: ");
        try {
            System.out.println(new BusinessLogic().showTopThreeProducts("food"));
            System.out.println(new BusinessLogic().showTopThreeProducts("Apparel"));
            System.out.println(new BusinessLogic().showTopThreeProducts("Electronics"));
        } catch (CustomException ex) {
            Logger.getLogger(View.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
