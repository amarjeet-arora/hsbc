/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam.Exception;

/**
 *
 * @author surya
 */
public class ProductAlreadyExistsException extends CustomException{
    public ProductAlreadyExistsException() {
		super();
		
	}

	public ProductAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ProductAlreadyExistsException(String message) {
		super(message);
		
	}

	public ProductAlreadyExistsException(Throwable cause) {
		super(cause);
		
	}
}
