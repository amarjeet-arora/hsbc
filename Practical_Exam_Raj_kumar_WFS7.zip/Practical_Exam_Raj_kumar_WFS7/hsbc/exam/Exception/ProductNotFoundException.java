/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsbc.exam.Exception;

/**
 *
 * @author surya
 */
public class ProductNotFoundException extends CustomException{
    public ProductNotFoundException() {
		super();
		
	}

	public ProductNotFoundException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ProductNotFoundException(String message) {
		super(message);
		
	}

	public ProductNotFoundException(Throwable cause) {
		super(cause);
		
	}
}
