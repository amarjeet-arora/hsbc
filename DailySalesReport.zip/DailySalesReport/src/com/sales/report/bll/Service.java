/**
 * 
 */
package com.sales.report.bll;
//this class call the particular methods of the particular objects.
import java.util.ArrayList;

import com.sales.report.dao.ApparelDaoImplemention;
import com.sales.report.dao.FoodDaoImplemention;
import com.sales.report.dao.ItemsDao;
import com.sales.report.entity.Apparel;
import com.sales.report.entity.FoodItems;
import com.sales.report.entity.Item;
import com.sales.report.exceptions.ItemException;

/**
 * @author mrunal
 *
 */
public class Service {
	
	FoodDaoImplemention daoFood = new FoodDaoImplemention();
	ApparelDaoImplemention daoApparel = new ApparelDaoImplemention();
	//ItemsDao daoElectronics new ElectronicDaoImplementation();
	
	public void addItem(FoodItems item) throws ItemException{
		daoFood.addNewItems(item);
	}
	
	public void addItem(Apparel item) throws ItemException{
		daoApparel.addNewItems(item);
	}
	
	public ArrayList<FoodItems> retrieveData() throws ItemException {
		ArrayList<Item> list = null;
		list = this.retrieveData();
		return list;
	}
	
	
	
}
