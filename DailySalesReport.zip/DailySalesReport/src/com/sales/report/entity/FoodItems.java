/**
 * 
 */
package com.sales.report.entity;

import java.util.Date;

/**
 * @author mrunal
 *
 */

public class FoodItems extends Item{

		private Date dateOfManufacture, dateOfExpiry;
		private String vegitarian;
		private Item item;
		
		/**
		 * 
		 */
		public FoodItems() {
			super();
			// TODO Auto-generated constructor stub
		}

		
		/**
		 * @param dateOfManufacture
		 * @param dateOfExpiry
		 * @param vegitarian
		 */
		public FoodItems(Date dateOfManufacture, Date dateOfExpiry, String vegitarian) {
			super();
			this.dateOfManufacture = dateOfManufacture;
			this.dateOfExpiry = dateOfExpiry;
			this.vegitarian = vegitarian;
		}


		/**
		 * @param dateOfManufacture
		 * @param dateOfExpiry
		 * @param vegitarian
		 */
		public FoodItems(Date dateOfManufacture, Date dateOfExpiry, String vegitarian, int itemCode, int quantity, String itemName, float itemPrice) {
			super(itemCode, quantity, itemName, itemPrice);
			this.dateOfManufacture = dateOfManufacture;
			this.dateOfExpiry = dateOfExpiry;
			this.vegitarian = vegitarian;
		}


		/**
		 * @return the dateOfManufacture
		 */
		public Date getDateOfManufacture() {
			return dateOfManufacture;
		}


		/**
		 * @param dateOfManufacture the dateOfManufacture to set
		 */
		public void setDateOfManufacture(Date dateOfManufacture) {
			this.dateOfManufacture = dateOfManufacture;
		}


		/**
		 * @return the dateOfExpiry
		 */
		public Date getDateOfExpiry() {
			return dateOfExpiry;
		}


		/**
		 * @param dateOfExpiry the dateOfExpiry to set
		 */
		public void setDateOfExpiry(Date dateOfExpiry) {
			this.dateOfExpiry = dateOfExpiry;
		}


		/**
		 * @return the vegitarian
		 */
		public String getVegitarian() {
			return vegitarian;
		}


		/**
		 * @param vegitarian the vegitarian to set
		 */
		public void setVegitarian(String vegitarian) {
			this.vegitarian = vegitarian;
		}


		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = super.hashCode();
			result = prime * result + ((dateOfExpiry == null) ? 0 : dateOfExpiry.hashCode());
			result = prime * result + ((dateOfManufacture == null) ? 0 : dateOfManufacture.hashCode());
			result = prime * result + ((vegitarian == null) ? 0 : vegitarian.hashCode());
			return result;
		}


		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (!super.equals(obj))
				return false;
			if (getClass() != obj.getClass())
				return false;
			FoodItems other = (FoodItems) obj;
			if (dateOfExpiry == null) {
				if (other.dateOfExpiry != null)
					return false;
			} else if (!dateOfExpiry.equals(other.dateOfExpiry))
				return false;
			if (dateOfManufacture == null) {
				if (other.dateOfManufacture != null)
					return false;
			} else if (!dateOfManufacture.equals(other.dateOfManufacture))
				return false;
			if (vegitarian == null) {
				if (other.vegitarian != null)
					return false;
			} else if (!vegitarian.equals(other.vegitarian))
				return false;
			return true;
		}


		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "FoodItems [dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry
					+ ", vegitarian=" + vegitarian + ", item=" + item + "]";
		}
		
		
			
}
