/**
 * 
 */
package com.sales.report.entity;

/**
 * @author mrunal
 *
 */
public class Apparel extends Item {
	
	private String size, material;
	Item item;
	/**
	 * @param size
	 * @param material
	 */
	public Apparel(String size, String material,int itemCode, int quantity, String itemName, float itemPrice) {
		super(itemCode, quantity, itemName, itemPrice);
		this.size = size;
		this.material = material;
	}
	/**
	 * 
	 */
	public Apparel() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param size
	 * @param material
	 */
	public Apparel(String size, String material) {
		super();
		this.size = size;
		this.material = material;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Apparel [size=" + size + ", material=" + material + ", item=" + item + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		result = prime * result + ((material == null) ? 0 : material.hashCode());
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Apparel other = (Apparel) obj;
		if (item == null) {
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		if (material == null) {
			if (other.material != null)
				return false;
		} else if (!material.equals(other.material))
			return false;
		if (size == null) {
			if (other.size != null)
				return false;
		} else if (!size.equals(other.size))
			return false;
		return true;
	}
	
	
	
	
	

}
