/**
 * 
 */
package com.sales.report.entity;

/**
 * @author mrunal
 *
 */
public class ElectronicsItem extends Item{

	private int warrantyMonths;
	private Item item;
	/**
	 * @param warrantyMonths
	 */
	public ElectronicsItem(int warrantyMonths) {
		super();
		this.warrantyMonths = warrantyMonths;
	}
	/**
	 * @param warrantyMonths
	 * @param item
	 */
	public ElectronicsItem(int warrantyMonths, Item item) {
		super();
		this.warrantyMonths = warrantyMonths;
		this.item = item;
	}
	/**
	 * 
	 */
	public ElectronicsItem() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param itemCode
	 * @param quantity
	 * @param itemName
	 * @param itemPrice
	 */
	public ElectronicsItem(int itemCode, int quantity, String itemName, float itemPrice,int warrantyMonths) {
		super(itemCode, quantity, itemName, itemPrice);
		this.warrantyMonths = warrantyMonths;
		// TODO Auto-generated constructor stub
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ElectronicsItem [warrantyMonths=" + warrantyMonths + ", item=" + item + "]";
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		result = prime * result + warrantyMonths;
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		ElectronicsItem other = (ElectronicsItem) obj;
		if (item == null) {
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		if (warrantyMonths != other.warrantyMonths)
			return false;
		return true;
	}
	
	
	
	
}
