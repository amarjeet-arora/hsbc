package com.sales.report.entity;

/**
 * @author mrunal
 *
 */
//Item class contains the basic properties of a particular item.
public class Item {
	
	private int itemCode, quantity;
	private String itemName;
	private float itemPrice;
	
	
	public Item(){
		super();
	}


	/**
	 * @param itemCode
	 * @param quantity
	 * @param itemName
	 * @param itemPrice
	 */
	public Item(int itemCode, int quantity, String itemName, float itemPrice) {
		super();
		this.itemCode = itemCode;
		this.quantity = quantity;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
	}


	

	

	/**
	 * @return the itemCode
	 */
	public int getItemCode() {
		return itemCode;
	}






	/**
	 * @param itemCode the itemCode to set
	 */
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}






	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}






	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}






	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}






	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}






	/**
	 * @return the itemPrice
	 */
	public float getItemPrice() {
		return itemPrice;
	}






	/**
	 * @param itemPrice the itemPrice to set
	 */
	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}






	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + itemCode;
		result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
		result = prime * result + Float.floatToIntBits(itemPrice);
		result = prime * result + quantity;
		return result;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (itemCode != other.itemCode)
			return false;
		if (itemName == null) {
			if (other.itemName != null)
				return false;
		} else if (!itemName.equals(other.itemName))
			return false;
		if (Float.floatToIntBits(itemPrice) != Float.floatToIntBits(other.itemPrice))
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Item [itemCode=" + itemCode + ", quantity=" + quantity + ", itemName=" + itemName + ", itemPrice="
				+ itemPrice + "]";
	}
	
	

}
