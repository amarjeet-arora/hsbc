/**
 * 
 */
package com.sales.report.exceptions;
//This is User Defined Exception Classto handle exceptions more efficiently.
/**
 * @author mrunal
 *
 */
public class ItemException extends Exception{

	/**
	 * @param message
	 * @param cause
	 */
	public ItemException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ItemException(String string) {
		// TODO Auto-generated constructor stub
	}
	
	

}
