package com.sales.report.view;

import com.sales.report.entity.FoodItems;
import com.sales.report.entity.Item;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
