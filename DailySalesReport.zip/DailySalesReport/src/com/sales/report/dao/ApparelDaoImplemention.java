/**
 * 
 */
package com.sales.report.dao;
//This class implements ItemsDao interface which contains the method to
//add apparel items and retrieve apparel items report.
import java.util.ArrayList;
import java.util.Collections;

import com.sales.report.entity.Apparel;
import com.sales.report.entity.FoodItems;
import com.sales.report.entity.Item;
import com.sales.report.exceptions.ItemException;

/**
 * @author mrunal
 *
 */
public class ApparelDaoImplemention implements ItemsDao {

	
	
	
		
		ArrayList<Apparel> list = new ArrayList<Apparel>();
		public void addNewItems(Item item) throws ItemException {
			list.add(item);
		}

		
		public  ArrayList<Apparel> retrieveReport() throws ItemException {
			// TODO Auto-generated method stub
		Collections.sort(list, new QuantitySorting());
			return list;
				
		}
	}

}
