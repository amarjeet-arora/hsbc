/**
 * 
 */
package com.sales.report.dao;
//This class implements ItemsDao interface which contains the method to
//add Food items and retrieve apparel items report.
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import com.sales.report.entity.FoodItems;
import com.sales.report.entity.Item;
import com.sales.report.exceptions.ItemException;

/**
 * @author mrunal
 *
 */
public class FoodDaoImplemention implements ItemsDao {

	//Map<Integer, FoodItems> list = new Map<Integer, FoodItems>();
	ArrayList<FoodItems> list = new ArrayList<FoodItems>();
	public void addNewItems(FoodItems item) throws ItemException {
		list.add(item);
	}

	
	public  ArrayList<FoodItems> retrieveReport() throws ItemException {
		// TODO Auto-generated method stub
	Collections.sort(list, new QuantitySorting());
		return list;
			
	}

}
