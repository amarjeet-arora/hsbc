/**
 * 
 */
package com.sales.report.dao;
//This Iterface contains addnewItems method and retrieve report method
//which is further Implemented by ApparelDaoImplemention, ElectronicdaoImplementation,FoodDaoImplemention classes.
import java.util.ArrayList;

import com.sales.report.entity.FoodItems;
import com.sales.report.entity.Item;
import com.sales.report.exceptions.ItemException;

/**
 * @author mrunal
 *
 */
public interface ItemsDao {

	public void addNewItems(Item item) throws ItemException;
	public ArrayList<Item> retrieveReport() throws ItemException;
}
