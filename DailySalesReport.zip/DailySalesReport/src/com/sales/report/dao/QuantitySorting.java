/**
 * 
 */
package com.sales.report.dao;

import java.util.Comparator;

import com.sales.report.entity.FoodItems;
import com.sales.report.entity.Item;

/**
 * @author mrunal
 *
 */
public class QuantitySorting implements Comparator<Item>{

	@Override
	public int compare(Item o1, Item o2) {
		// TODO Auto-generated method stub
		return o1.getQuantity()-o2.getQuantity();
	}

}
