/**
 * 
 */
package com.sales.report.dao;
import java.util.ArrayList;
import java.util.Collections;

import com.sales.report.entity.Apparel;
import com.sales.report.entity.ElectronicsItem;
import com.sales.report.entity.Item;
////This class implements ItemsDao interface which contains the method to
//add Electronics items and retrieve apparel items report.
import com.sales.report.exceptions.ItemException;

/**
 * @author mrunal
 *
 */
public class ElectronicdaoImplementation implements ItemsDao{

	ArrayList<ElectronicsItem> list = new ArrayList<ElectronicsItem>();
	
	@Override
	public void addNewItems(Item item) throws ItemException {
		// TODO Auto-generated method stub
		list.add(item);
		
	}

	@Override
	public ArrayList<Item> retrieveReport() throws ItemException {
		// TODO Auto-generated method stub
		Collections.sort(list, new QuantitySorting());
		return list;
	}

	
	

}
