/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This class ElectronicsdaoImpl is a part of the daoimpl package.
 * This class contains implements Electronicsdoa interface
 * */
package daoimpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import dao.ElectronicExists;
import dao.Appareldao;
import practical.model.Electronics;
import practical.model.Electronics;
public class ElectronicsdaoImpl implements Electronicsdao{
		
		private Map <Integer,Electronics>electrnoics=new HashMap<Integer,Electronicss>();

		@Override
		public Electronics addItem(Electronics item) throws ElectronicsExists {
			if(electronics.containsKey(item.get(itemCode())))
			{
				electronics.put(item.itemCode(),itemName);
			}
			return electronics;
		}
		
	}
