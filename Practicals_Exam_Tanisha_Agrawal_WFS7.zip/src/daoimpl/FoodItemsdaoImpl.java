/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This class FoodItemsdaoImpl is a part of the daoimpl package.
 * This class contains implements FoodItemsdoa inteface
 * */
package daoimpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import dao.FoodItemExists;
import dao.FoodItemsdao;
import practical.model.FoodItems;


public class FoodItemsdaoImpl implements FoodItemsdao {
	
	//creating hashmap to store ids and details of the items
	private Map <Integer,FoodItems>foodItems=new HashMap<Integer,FoodItems>();

	@Override
	//implementing the function in interface
	public FoodItems addItem(FoodItems item) throws FoodItemExists {
		// TODO Auto-generated method stub
		if(foodItems.containsKey(item.get(itemCode())))
		{
			foodItems.put(item.itemCode(),itemName);
		}
		return foodItems;
	}
	
	
	
}
