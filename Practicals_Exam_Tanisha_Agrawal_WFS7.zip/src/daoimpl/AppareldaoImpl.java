/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This class AppareldaoImpl is a part of the daoimpl package.
 * This class contains implements Appareldoa inteface
 * */
package daoimpl;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import dao.ApparelExists;
import dao.Appareldao;
import practical.model.Apparel;
import practical.model.FoodItems;
public class AppareldaoImpl implements Appareldao{
	
	private Map <Integer,FoodItems>apps=new HashMap<Integer,FoodItems>();
	//implenting the interface function
	@Override
	public Apparel addItem(Apparel item) throws ApparelExists {
		//checking if the item exists and adding it to the map
		if(apps.containsKey(item.get(itemCode())))
		{
			apps.put(item.itemCode(),itemName);
		}
		return apps;
	}
	
}
