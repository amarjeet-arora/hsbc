/*
 * AUTHOR: TANISHA AGRAWAL
 * BRIEF:This class Electronics is a part of the practical.model package.
 * This class contains the data variables used to store information about the item code, name of the product, unit price of the product,
 * warranty pperiod of the product and the quantity as per user.
 */
package practical.model;

public class Electronics {
	int itemCode;
	String itemName;
	double unitPrice;
	double warranty;//double because it can be 11 and half months
	int quantity;
	
	//This is the default constructor of Electronics class
	
	public Electronics() {
		super();
	}
	
	//Parameterized constructor of Electronics which will be used to input values from the user and store in an ArrayList
	
	public Electronics(int itemCode, String itemName, double unitPrice, double warranty, int quantity) {
		
		//initializing the global variables with the user passed values in the local variables(pass by value as all are primitive data types)
		
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.warranty = warranty;
		this.quantity = quantity;
	}
	
	//invoking getter and setter methods to get and set the values of the data variables
	
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public double getWarranty() {
		return warranty;
	}
	public void setWarranty(double warranty) {
		this.warranty = warranty;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	// toString method invoked to display the values
	
	@Override
	public String toString() {
		return "Electronics [itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", warranty=" + warranty + ", quantity=" + quantity + "]";
	}
	
	
}
