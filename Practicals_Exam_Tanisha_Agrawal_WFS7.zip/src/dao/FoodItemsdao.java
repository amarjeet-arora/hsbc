/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This interface FoodItemsdao is a part of the dao package.
 * This interface contains the methods addItem and collection of FoodItem type to retrieve data stored
 * */
package dao;
import java.util.Collections;

import practical.model.FoodItems;
public interface FoodItemsdao {
	public Collection<FoodItems>getFoodItemDetails();
	public FoodItems addItem(FoodItems item)throws FoodItemExists; //checks if the fooditem already exists

}
