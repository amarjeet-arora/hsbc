/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This interface Appareldao is a part of the dao package.
 * This interface contains the methods addItem and collection of ElectronicItem type to retrieve data stored
 * */
package dao;
import java.util.Collections;
import practical.model.Apparel;
import practical.model.FoodItems;
public interface Appareldao {
	public Collections<Apparel>getApparelDetails();
	public Apparel addItem(Apparel item)throws ApparelExists; //checks if the fooditem already exists
	

}
