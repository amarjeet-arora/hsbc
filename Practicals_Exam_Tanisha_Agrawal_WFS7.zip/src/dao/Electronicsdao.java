/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This interface Electronicsdao is a part of the dao package.
 * This interface contains the methods addItem and collection of ElectronicItem type to retrieve data stored
 * */
package dao;
import java.util.Collections;

import practical.model.Electronics;

public interface Electronicsdao {
	//public Collections<Electronics>getElectronicsDetails();
	public Electronics addItem(Electronics item)throws ElectronicExists; //checks if the fooditem already exists

}
