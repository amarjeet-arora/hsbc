/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This class is a part of Exceptions package and helps to check if apparel already exists in the arraylist
 * */
package Exceptions;

public class FoodItemExist extends Exception {
	public FoodItemExist()
	{
		super();
	}
	public FoodItemExist(String message)
	{
		super(message);
	}


}
