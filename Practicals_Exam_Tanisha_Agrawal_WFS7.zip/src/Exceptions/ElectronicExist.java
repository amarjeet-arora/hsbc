/*AUTHOR: TANISHA AGRAWAL
 * BRIEF: This class is a part of Exceptions package and helps to check if apparel already exists in the arraylist
 * */
package Exceptions;

public class ElectronicExist extends Exception {
	public ElectronicExist()
	{
		super();
	}
	public ElectronicExist(String message)
	{
		super(message);
	}
	
}
