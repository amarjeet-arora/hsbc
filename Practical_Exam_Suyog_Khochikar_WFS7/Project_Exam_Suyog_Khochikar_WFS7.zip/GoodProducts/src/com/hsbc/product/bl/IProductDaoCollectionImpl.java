/*
 * Author:Suyog Khochikar
 * Purpose:this class implements IproductDao interface methods
 */


package com.hsbc.product.bl;

import java.util.ArrayList;
import com.hsbc.product.dao.IProductDao;
import com.hsbc.product.entity.*;
import com.hsbc.product.exception.ProductException;

public class IProductDaoCollectionImpl implements IProductDao {

	ArrayList<FoodItems> listf = new ArrayList<FoodItems>();
	ArrayList<Apparel> lista = new ArrayList<Apparel>();
	ArrayList<Electonics> liste = new ArrayList<Electonics>();
	@Override
	public void saveProduct(FoodItems f) throws ProductException {
		// TODO Auto-generated method stub
		listf.add(new FoodItems() );
	}

	@Override
	public void saveProduct(Apparel a) throws ProductException {
		// TODO Auto-generated method stub
		lista.add(new Apparel());
	}

	@Override
	public void saveProduct(Electonics e) throws ProductException {
		// TODO Auto-generated method stub
		liste.add(new Electonics());
	}

	@Override
	public ArrayList<FoodItems> findProducts() throws ProductException {
		// TODO Auto-generated method stub
		return listf;
	}

	@Override
	public ArrayList<Apparel> findProducts1() throws ProductException {
		// TODO Auto-generated method stub
		return lista;
	}

	@Override
	public ArrayList<Electonics> findProducts3() throws ProductException {
		// TODO Auto-generated method stub
		return liste;
	}

	

	

}
