/*
 * Author:Suyog Khochikar
 * Purpose:Apparel class and its attributes
 */

package com.hsbc.product.entity;


public class Apparel {

	private int itemCode;
	private String itemName;
	private int price;
	private Size size;
	private Material material;
	private int Quantity;
	
	//constructor
	public Apparel() {
		super();

	}
	
	//getter and setter
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Size getSize() {
		return size;
	}
	public void setSize(Size size) {
		this.size = size;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	
}
