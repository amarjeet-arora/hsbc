/*
 * Author:Suyog Khochikar
 * Purpose:Electonics class and its attributes
 */

package com.hsbc.product.entity;

public class Electonics {
	private int itemCode;
	private String itemName;
	private int price;
	private int warrenty;
	private int quantity;
	
	//constructor
	public Electonics() {
		super();
	}
	
	//getter and setter
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getWarrenty() {
		return warrenty;
	}
	public void setWarrenty(int warrenty) {
		this.warrenty = warrenty;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
