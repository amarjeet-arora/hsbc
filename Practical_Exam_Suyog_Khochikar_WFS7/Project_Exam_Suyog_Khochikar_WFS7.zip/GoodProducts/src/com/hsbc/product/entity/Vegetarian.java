package com.hsbc.product.entity;

public enum Vegetarian {
Yes,No
}
