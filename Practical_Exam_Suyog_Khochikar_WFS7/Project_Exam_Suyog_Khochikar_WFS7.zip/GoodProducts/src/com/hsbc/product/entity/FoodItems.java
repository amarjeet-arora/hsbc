/*
 * Author:Suyog Khochikar
 * Purpose:FoodItems class and its attibutes
 */
package com.hsbc.product.entity;

import java.time.LocalDate;

public class FoodItems {

		private int itemCode;
		
		private String itemName;
		private int price;
		private LocalDate manDate;
		private LocalDate expDate;
		private Vegetarian vegeterian;
		private int Quantity;
		//constructor
		public FoodItems() {
			super();
		}
		
		//getter and setter
		public int getItemCode() {
			return itemCode;
		}
		public void setItemCode(int itemCode) {
			this.itemCode = itemCode;
		}
		public String getItemName() {
			return itemName;
		}
		public void setItemName(String itemName) {
			this.itemName = itemName;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public LocalDate getManDate() {
			return manDate;
		}
		public void setManDate(LocalDate manDate) {
			this.manDate = manDate;
		}
		public LocalDate getExpDate() {
			return expDate;
		}
		public void setExpDate(LocalDate expDate) {
			this.expDate = expDate;
		}
		public Vegetarian getVegeterian() {
			return vegeterian;
		}
		public void setVegeterian(Vegetarian vegeterian) {
			this.vegeterian = vegeterian;
		}
		public int getQuantity() {
			return Quantity;
		}
		public void setQuantity(int quantity) {
			Quantity = quantity;
		}
		@Override
		public String toString() {
			return "FoodItems [itemCode=" + itemCode + ", itemName=" + itemName + ", price=" + price + ", manDate="
					+ manDate + ", expDate=" + expDate + ", vegeterian=" + vegeterian + ", Quantity=" + Quantity + "]";
		}
		
}
