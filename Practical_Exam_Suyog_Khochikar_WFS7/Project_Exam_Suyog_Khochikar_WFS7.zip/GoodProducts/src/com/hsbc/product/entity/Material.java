package com.hsbc.product.entity;

public enum Material {
cotton,wollen
}
