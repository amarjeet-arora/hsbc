package com.hsbc.product.entity;

public enum Size {
small,medium,large
}
