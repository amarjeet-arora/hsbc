/*
 * Author:Suyog Khochikar
 * Purpose:this is a IproductDao interfaceClass
 */

package com.hsbc.product.dao;

import java.util.Collection;

import com.hsbc.product.exception.ProductException;
import com.hsbc.product.entity.*;
public interface IProductDao {
	
	void saveProduct(FoodItems f) throws ProductException ;
	void saveProduct(Apparel a) throws ProductException;
	void saveProduct(Electonics e) throws ProductException;
	Collection<FoodItems> findProducts() throws ProductException;
	Collection<Apparel> findProducts1() throws ProductException;
	Collection<Electonics> findProducts3() throws ProductException;
}
