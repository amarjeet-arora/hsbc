package com.hsbc.exceptions;
/*
 * Author: Ujjwal Mishra
 * Purpose: NoProductExistsException
 */
@SuppressWarnings("serial")
public class NoProductExistsException extends Exception {
	
	public NoProductExistsException() {
		super();
	}
	
	public NoProductExistsException(Throwable cause) {
		super(cause);
	}
	
	public NoProductExistsException(String message) {
		super(message);
	}
	
	public NoProductExistsException(String message, Throwable cause) {
		super(message, cause);
	}
}
