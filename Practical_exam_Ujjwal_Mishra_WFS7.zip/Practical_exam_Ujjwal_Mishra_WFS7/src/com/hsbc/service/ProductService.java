package com.hsbc.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hsbc.dao.ProductDAO;
import com.hsbc.entity.Product;
import com.hsbc.exceptions.NoProductExistsException;
import com.hsbc.exceptions.ProductAlreadyExistsException;
import com.hsbc.exceptions.ProductNotFoundException;


/*
 * Author: Ujjwal Mishra
 * 
 * Purpose: This program performs CRUD operation for Product entity.
 * 			1. It adds a new product. Exception is thrown if product with existing itemCode is tried to add
 * 			2. It remove a product with supplied itemCode. Throws an exception if itemCode does not exist.
 * 			3. It updates  a product with new details. Throws exception if itemCode does not exist
 * 			4. It obtains the entire list of products.
 * 			5. It obtains the product on the basis of itemCode. Throws an exception if itemCode does not exist
 * 
 */
public class ProductService implements ProductDAO {
	
	private Map<Integer,Product> productList = new HashMap<Integer, Product>();
	
	/*
	 * (non-Javadoc)
	 * @see com.hsbc.dao.ProductDAO#addProduct(com.hsbc.entity.Product)
	 * 
	 *  It adds a new product. Exception is thrown if product with existing itemCode is tried to add
	 */
	@Override
	public void addProduct(Product product) throws ProductAlreadyExistsException {
		if(productList.containsKey(product.getItemCode())) 
			throw new ProductAlreadyExistsException("Product already exists");
		
		productList.put(product.getItemCode(), product);
	}
	/*
	 * (non-Javadoc)
	 * @see com.hsbc.dao.ProductDAO#removeProduct(int)
	 * It remove a product with supplied itemCode. Throws an exception if itemCode does not exist.
	 */
	@Override
	public Product removeProduct(int itemCode) throws ProductNotFoundException {
		if(!productList.containsKey(itemCode))
			throw new ProductNotFoundException("Product not found");
	
		return productList.remove(itemCode);
	}
	/*
	 * (non-Javadoc)
	 * @see com.hsbc.dao.ProductDAO#editProduct(int, com.hsbc.entity.Product)
	 *  It updates  a product with new details. Throws exception if itemCode does not exist
	 */

	@Override
	public Product editProduct(int itemCode, Product product) throws ProductNotFoundException {
		if(!productList.containsKey(itemCode))
			throw new ProductNotFoundException("Product not found");
		
		productList.put(itemCode, product);
		return product;
	}
	/*
	 * (non-Javadoc)
	 * @see com.hsbc.dao.ProductDAO#getProductByItemCode(int)
	 * It obtains the product on the basis of itemCode. Throws an exception if itemCode does not exist
	 */
	@Override
	public Product getProductByItemCode(int itemCode) throws ProductNotFoundException {
		if(!productList.containsKey(itemCode))
			throw new ProductNotFoundException("Product not found");
		
		return productList.get(itemCode);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.hsbc.dao.ProductDAO#getAllProducts()
	 * It obtains the entire list of products.
	 */
	@Override
	public Collection<Product> getAllProducts() throws NoProductExistsException {
		if(productList.size() == 0)
			throw new NoProductExistsException("No product found");
		
		return productList.values();
	}
	
	@Override
	public List<Product> getTopProducts() throws NoProductExistsException {
		if(productList.size() == 0)
			throw new NoProductExistsException("No product found");
		
		Collection<Product> products = productList.values();
		
		List<Product> productListUp = new ArrayList<Product>();
		
		for(Product product:products) {
			
			productListUp.add(product);
		}
		
		Collections.sort(productListUp);
		
		List<Product> productsTop = new ArrayList<Product>();
		productsTop.add(productListUp.get(0));
		productsTop.add(productListUp.get(1));
		productsTop.add(productListUp.get(2));
		
		return productsTop;
		
	}

}
