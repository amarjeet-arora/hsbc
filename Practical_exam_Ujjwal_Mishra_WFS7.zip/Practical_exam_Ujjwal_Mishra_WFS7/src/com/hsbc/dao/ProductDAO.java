package com.hsbc.dao;

import java.util.Collection;

import com.hsbc.entity.Product;
import com.hsbc.exceptions.NoProductExistsException;
import com.hsbc.exceptions.ProductAlreadyExistsException;
import com.hsbc.exceptions.ProductNotFoundException;

/*
 * Author: Ujjwal Mishra
 * Purpose: Interface of Product DAO
 */
public interface ProductDAO {
	public void addProduct(Product product) throws ProductAlreadyExistsException;
	public Product removeProduct(int itemCode) throws ProductNotFoundException;
	public Product editProduct(int itemCode, Product product) throws ProductNotFoundException;
	public Product getProductByItemCode(int itemCode) throws ProductNotFoundException;
	public Collection<Product> getAllProducts() throws NoProductExistsException;
	public Collection<Product> getTopProducts() throws NoProductExistsException; 
}
