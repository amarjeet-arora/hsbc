package com.hsbc.entity;

/*
 * Author: Ujjwal Mishra
 * Purpose: Size enum
 */
public enum Size {
	SMALL, MEDIUM, LARGE, XlARGE
}
