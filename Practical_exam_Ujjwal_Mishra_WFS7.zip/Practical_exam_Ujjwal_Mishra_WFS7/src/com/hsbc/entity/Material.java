package com.hsbc.entity;

/*
 * Author: Ujjwal Mishra
 * Purpose: Material Enum
 */
public enum Material {
	COTTON, WOOL
}
