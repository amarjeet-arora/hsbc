package com.hsbc.entity;

/*
 * Author: Ujjwal Mishra
 * Purpose: Electronics class
 */
public class Electronics extends Product {
	
	private int warranty;

	public Electronics() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Electronics(int itemCode, String itemName, int unitPrice, int quantity, int warranty) {
		super(itemCode, itemName, unitPrice, quantity);
		this.warranty = warranty;
	}

	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}

	@Override
	public String toString() {
		return "Electronics [warranty=" + warranty + ", itemCode=" + itemCode + ", itemName=" + itemName
				+ ", unitPrice=" + unitPrice + ", quantity=" + quantity + "]";
	}

	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return o.quantity - this.quantity;
	}
	
	
	
	

}
