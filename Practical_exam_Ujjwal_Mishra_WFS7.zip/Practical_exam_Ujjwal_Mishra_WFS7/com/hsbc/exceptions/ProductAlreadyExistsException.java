package com.hsbc.exceptions;

/*
 * Author: Ujjwal Mishra
 * Purpose: ProductAlreadyExistsException
 */
@SuppressWarnings("serial")
public class ProductAlreadyExistsException extends Exception {
	
	public ProductAlreadyExistsException() {
		super();
	}
	
	public ProductAlreadyExistsException(Throwable cause) {
		super(cause);
	}
	
	public ProductAlreadyExistsException(String message) {
		super(message);
	}
	
	public ProductAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
	}
}
