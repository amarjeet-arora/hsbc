package com.hsbc.exceptions;

/*
 * Author: Ujjwal Mishra
 * Purpose: ProductNotFoundException
 */
@SuppressWarnings("serial")
public class ProductNotFoundException extends Exception {
	
	public ProductNotFoundException() {
		super();
	}
	
	public ProductNotFoundException(Throwable cause) {
		super(cause);
	}
	
	public ProductNotFoundException(String message) {
		super(message);
	}
	
	public ProductNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}
