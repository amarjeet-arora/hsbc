package com.hsbc.view;


import java.util.Collection;
import java.util.Date;

import com.hsbc.entity.Apparel;
import com.hsbc.entity.Electronics;
import com.hsbc.entity.Food;
import com.hsbc.entity.Material;
import com.hsbc.entity.Product;
import com.hsbc.entity.Size;
import com.hsbc.exceptions.NoProductExistsException;
import com.hsbc.exceptions.ProductAlreadyExistsException;
import com.hsbc.exceptions.ProductNotFoundException;
import com.hsbc.service.ProductService;
/*
 * Author: Ujjwal Mishra
 * Purpose: Client code for testing
 */
public class Client {

	public static void main(String[] args) {
		
		Product e1 = new Electronics(1013, "TV", 3000, 1, 18);
	
		
		Product a1 = new Apparel(222, "T-shirt", 999, 50, Size.LARGE, Material.COTTON);
		
		
		Product f1 = new Food(101, "Milk", 40, 5, new Date(), new Date(), true);
		
		ProductService productService = new ProductService();
		
		try {
			productService.addProduct(e1);
			productService.addProduct(a1);
			productService.addProduct(f1);
		} catch (ProductAlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Collection<Product> products;
		try {
			products = productService.getAllProducts();
		
			for(Product product : products ) {
				System.out.println(product);
			}
		} catch (NoProductExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		e1.setQuantity(5);
		
		try {
			productService.editProduct(1013, e1);
			products = productService.getAllProducts();
			System.out.println("After editing:");
			for(Product product : products ) {
				System.out.println(product);
			}
		} catch (ProductNotFoundException | NoProductExistsException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
	
		try {
			Product product = productService.removeProduct(222);
			System.out.println("Product Remove: " + product);
			products = productService.getAllProducts();
			System.out.println("After deletion:");
			for(Product productR : products ) {
				System.out.println(productR);
			}
		} catch (ProductNotFoundException | NoProductExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			Product product = productService.getProductByItemCode(222);
			System.out.println("Product Get By Item Code (Exception Case): " + product);
			
		} catch (ProductNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			Product product = productService.getProductByItemCode(101);
			System.out.println("Product Get By Item Code: " + product);
			
		} catch (ProductNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
