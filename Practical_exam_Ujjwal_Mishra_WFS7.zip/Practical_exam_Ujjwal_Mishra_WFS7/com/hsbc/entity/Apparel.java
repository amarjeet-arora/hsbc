package com.hsbc.entity;

/*
 * Author: Ujjwal Mishra
 * Purpose: Apparel class
 */
public class Apparel extends Product {
	
	private Size size;
	private Material material;
	public Apparel() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Apparel(int itemCode, String itemName, int unitPrice, int quantity, Size size, Material material) {
		super(itemCode, itemName, unitPrice, quantity);
		this.size = size;
		this.material = material;
	}
	
	public Size getSize() {
		return size;
	}
	public void setSize(Size size) {
		this.size = size;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	@Override
	public String toString() {
		return "Apparel [size=" + size + ", material=" + material + ", itemCode=" + itemCode + ", itemName=" + itemName
				+ ", unitPrice=" + unitPrice + ", quantity=" + quantity + "]";
	}
	
	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return this.itemCode - o.itemCode;
	}
	
}
