package com.hsbc.entity;

import java.util.Date;

/*
 * Author: Ujjwal Mishra
 * Purpose: Food class
 */
public class Food extends Product {
	
	private Date dateOfManufacture;
	private Date dateOfExpiry;
	private boolean isVegetarian;
	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Food(int itemCode, String itemName, int unitPrice, int quantity, Date dateOfManufacture, Date dateOfExpiry, boolean isVegetarian) {
		super(itemCode, itemName, unitPrice, quantity);
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpiry = dateOfExpiry;
		this.isVegetarian = isVegetarian;
	}
	public Date getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(Date dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public boolean isVegetarian() {
		return isVegetarian;
	}
	public void setVegetarian(boolean isVegetarian) {
		this.isVegetarian = isVegetarian;
	}
	@Override
	public String toString() {
		return "Food [dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", isVegetarian="
				+ isVegetarian + ", itemCode=" + itemCode + ", itemName=" + itemName + ", unitPrice=" + unitPrice
				+ ", quantity=" + quantity + "]";
	}
	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return this.itemCode - o.itemCode;
	}
	
	
	

}
